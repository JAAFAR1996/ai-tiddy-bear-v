#include "hardware.h"
#include "audio_handler.h"
#include "config.h"
#include <WiFi.h>

// 🧸 Audio-Only AI Teddy Bear Hardware
// Simple button + audio implementation - No visual components

// Hardware initialization
void initHardware() {
  // Initialize button pin with pullup (hidden inside teddy bear)
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  
  // Initialize speaker pin for audio output
  pinMode(SPEAKER_PIN, OUTPUT);
  digitalWrite(SPEAKER_PIN, LOW);
  
  Serial.println("🧸 Teddy Bear hardware initialized (Audio-only mode)");
}

// 🧸 Audio-Only Functions (No LEDs in teddy bear design)
// All visual feedback removed - Teddy bear uses only audio interaction

// Simplified compatibility functions (no-op implementations)
void clearLEDs() { /* No LEDs in teddy bear */ }
void setLEDColor(String color, int brightness) { /* Audio-only teddy bear */ }
void setLEDColor(int r, int g, int b, int brightness) { /* Audio-only teddy bear */ }

// Note: playTone and playMelody are implemented in audio_handler.cpp

// Audio feedback for system status (replaces visual animations)
void playSystemSound(int frequency, int duration) {
  // Simple tone on speaker for status feedback
  tone(SPEAKER_PIN, frequency, duration);
}

void playStartupSound() {
  // Teddy bear startup sound
  playSystemSound(1000, 200);
  delay(100);
  playSystemSound(1200, 200);
}

void playConnectionSound() {
  // WiFi connected sound
  playSystemSound(800, 100);
  delay(50);
  playSystemSound(1000, 100);
  delay(50);
  playSystemSound(1200, 150);
}

void playErrorSound() {
  // Error sound
  playSystemSound(400, 300);
  delay(100);
  playSystemSound(300, 300);
}

// Compatibility stubs (no-op since no LEDs exist)
void playStreamingAnimation() { /* Audio-only mode */ }
void playHappyAnimation() { /* Audio-only mode */ }
void playSadAnimation() { /* Audio-only mode */ }
void playExcitedAnimation() { /* Audio-only mode */ }
void playWelcomeAnimation() { playStartupSound(); }
void playRainbowAnimation() { /* Audio-only mode */ }
void playBreathingAnimation(int r, int g, int b) { /* Audio-only mode */ }
void blinkLED(int r, int g, int b, int times, int delayMs) { /* Audio-only mode */ }
void fadeInOut(int r, int g, int b, int duration) { /* Audio-only mode */ }

void setLEDAnimation(int mode, int r, int g, int b, uint8_t brightness) { /* Audio-only mode */ }
void setBreathingMode(int r, int g, int b, uint8_t brightness) { /* Audio-only mode */ }
void setPulseMode(int r, int g, int b, uint8_t brightness) { /* Audio-only mode */ }

void showAudioReactive(bool enabled) { /* Audio-only mode */ }
void showNetworkStatus(bool show) { if(show) playConnectionSound(); }
void showBatteryLevel(bool show) { /* Audio-only mode */ }
void setRainbowMode(uint8_t brightness) { /* Audio-only mode */ }
void setAudioReactiveMode(bool enabled) { /* Audio-only mode */ }

// System compatibility stubs
void updateLEDAnimationSystem() { /* No LEDs */ }
void updateAudioReactiveAnimation() { /* No LEDs */ }
void updateNetworkStatusAnimation() { /* No LEDs */ }
void updateBatteryLevelAnimation() { /* No LEDs */ }
void updateBreathingAnimation() { /* No LEDs */ }
void updateRainbowAnimation() { /* No LEDs */ }
void updatePulseAnimation() { /* No LEDs */ }
void updateLEDTransition() { /* No LEDs */ }
void updateAudioLevel(uint16_t level) { /* Audio processing in audio_handler.cpp */ }
void updateBatteryStatus(float percent, bool charging) { /* No visual indicators */ }
void updateNetworkStatus(int rssi, bool connected, float quality) { /* No visual indicators */ }

int getCurrentLEDMode() { return 0; }
bool isLEDTransitioning() { return false; }
void setLEDAnimationSpeed(uint16_t speedMs) { /* No LEDs */ }