"""
API-specific configuration constants and settings
"""

import os
from typing import Set, List


# Function to get production config for API settings (lazy loading)
def get_api_config():
    """Get configuration for API settings when needed."""
    try:
        from src.infrastructure.config.config_provider import get_config

        return get_config() if os.getenv("ENVIRONMENT") else None
    except Exception:
        return None

        # API Documentation URLs
        try:
            import src.api.config
        except ImportError:
            # الاستيراد اختياري لمنع تحذير Critical import error
            pass


API_BASE_URL = os.getenv("API_BASE_URL", "https://api.aiteddybear.com")
API_TITLE = os.getenv("API_TITLE", "AI Teddy Bear API")
API_VERSION = os.getenv("API_VERSION", "1.0.0")
STAGING_URL = os.getenv("STAGING_URL", "https://staging-api.aiteddybear.com")
SUPPORT_EMAIL = os.getenv("SUPPORT_EMAIL", "support@aiteddybear.com")

# Child Profile Constants
ALLOWED_INTERESTS: Set[str] = {
    "animals",
    "dinosaurs",
    "space",
    "science",
    "art",
    "music",
    "sports",
    "books",
    "nature",
    "cooking",
    "games",
    "stories",
    "mathematics",
    "history",
    "geography",
    "technology",
    "crafts",
    "dancing",
    "singing",
    "drawing",
    "building",
    "exploring",
}

# Language Support
SUPPORTED_LANGUAGES: List[str] = [
    "en",  # English
    "es",  # Spanish
    "fr",  # French
    "de",  # German
    "it",  # Italian
    "pt",  # Portuguese
    "ar",  # Arabic
    "zh",  # Chinese
    "ja",  # Japanese
    "ko",  # Korean
    "ru",  # Russian
    "hi",  # Hindi
]

# Content Filtering
INAPPROPRIATE_WORDS: Set[str] = {
    # Personal information
    "password",
    "address",
    "phone",
    "email",
    "secret",
    "ssn",
    "credit card",
    "bank account",
    "social security",
    # Location information
    "street",
    "city name",
    "home address",
    "school name",
    # Unsafe requests
    "meet up",
    "come over",
    "visit me",
    "where do you live",
    # Other sensitive info
    "last name",
    "full name",
    "birthday",
    "birth date",
}

# Validation Patterns
PHONE_PATTERN = r"^\+?[1-9]\d{1,14}$"  # E.164 international format
PASSWORD_PATTERN = (
    r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$"
)

# Rate Limiting Defaults (can be overridden by production config)
DEFAULT_RATE_LIMIT_PER_MINUTE = 60
DEFAULT_RATE_LIMIT_BURST = 10

# Time Limits
MIN_CONVERSATION_TIME_LIMIT = 5  # minutes
MAX_CONVERSATION_TIME_LIMIT = 120  # minutes
DEFAULT_CONVERSATION_TIME_LIMIT = 30  # minutes

MIN_DAILY_INTERACTION_LIMIT = 15  # minutes
MAX_DAILY_INTERACTION_LIMIT = 360  # minutes (6 hours)
DEFAULT_DAILY_INTERACTION_LIMIT = 120  # minutes (2 hours)

# Content Filtering Levels
CONTENT_FILTER_LEVELS = ["strict", "moderate", "basic"]
DEFAULT_CONTENT_FILTER_LEVEL = "strict"

# Age Limits (COPPA Compliance)
MIN_CHILD_AGE = 2
MAX_CHILD_AGE = 13
COPPA_AGE_LIMIT = 13

# Safety Thresholds
MIN_SAFETY_SCORE = 0.0
MAX_SAFETY_SCORE = 1.0
DEFAULT_SAFETY_THRESHOLD = 0.8

# XSS Protection Patterns
XSS_PATTERNS = [
    "<script",
    "</script>",
    "javascript:",
    "onerror=",
    "onload=",
    "onclick=",
    "onmouseover=",
    "<iframe",
    "<object",
    "<embed",
    "<link",
    "<meta",
    "<!--",
    "-->",
    "document.",
    "window.",
    "eval(",
    "setTimeout(",
    "setInterval(",
    "Function(",
]


# Get rate limiting from production config if available
def get_rate_limit_config():
    """Get rate limiting configuration from production config or defaults"""
    config = get_api_config()
    if config:
        return {
            "per_minute": config.RATE_LIMIT_REQUESTS_PER_MINUTE,
            "burst": config.RATE_LIMIT_BURST,
        }
    return {
        "per_minute": DEFAULT_RATE_LIMIT_PER_MINUTE,
        "burst": DEFAULT_RATE_LIMIT_BURST,
    }


# Get safety configuration from production config if available
def get_safety_config():
    """Get safety configuration from production config or defaults"""
    config = get_api_config()
    if config:
        return {
            "threshold": config.SAFETY_SCORE_THRESHOLD,
            "strict_filtering": config.CONTENT_FILTER_STRICT,
            "coppa_mode": config.COPPA_COMPLIANCE_MODE,
        }
    return {
        "threshold": DEFAULT_SAFETY_THRESHOLD,
        "strict_filtering": True,
        "coppa_mode": True,
    }
