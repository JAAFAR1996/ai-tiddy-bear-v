#include "wifi_manager.h"              // يجلب تصريح extern deviceConfig والنوع الحقيقي

// تعريف مطابق 1:1 للتصريح في wifi_manager.h
DeviceConfig deviceConfig{};