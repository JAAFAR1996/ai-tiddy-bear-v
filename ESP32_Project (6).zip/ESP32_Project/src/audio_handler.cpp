#include "audio_handler.h"
#include "feature_config.h"
#include "websocket_handler.h"
#include "hardware.h"
#include "monitoring.h"
#include "system_monitor.h"  // For production system monitoring
#include <driver/adc.h>       // ADC for analog microphone (HW-164)
#include <WiFi.h>
#include <math.h>
#include <esp_task_wdt.h>  // For watchdog reset
#include <driver/dac.h>    // ESP32 WROOM Ã™Å Ã˜Â¯Ã˜Â¹Ã™â€¦ DAC Ã˜Â¨Ã˜Â´Ã™Æ’Ã™â€ž Ã™Æ’Ã˜Â§Ã™â€¦Ã™â€ž
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/ringbuf.h"
#include "driver/i2s.h"
#include "esp_heap_caps.h"
  
// Production FreeRTOS priorities for audio
#define AUDIO_CAPTURE_PRIORITY   (configMAX_PRIORITIES - 2)  // Highest for audio capture
#define AUDIO_PLAYBACK_PRIORITY  (configMAX_PRIORITIES - 3)  // High for audio playback  
#define WEBSOCKET_SEND_PRIORITY  (configMAX_PRIORITIES - 4)  // Medium for network

// Reduced ring buffer sizes to prevent memory fragmentation
#define CAPTURE_RING_BYTES      (16 * 1024)  // 16KB for capture (reduced)
#define PLAYBACK_RING_BYTES     (16 * 1024)  // 16KB for playback (reduced)

AudioState currentAudioState = AUDIO_IDLE;
// Safe memory management with RAII pattern
static uint8_t* audioBuffer = nullptr;
size_t audioBufferSize = 0;
size_t audioBufferIndex = 0;
bool recordingActive = false;
bool audioInitialized = false;

// Ã¢Å“â€¦ Ã™â€¦Ã˜ÂªÃ˜ÂºÃ™Å Ã˜Â±Ã˜Â§Ã˜Âª Ã™â€žÃ™â€žÃ™â‚¬ streaming - Ã˜Â¥Ã˜ÂµÃ™â€žÃ˜Â§Ã˜Â­ Ã˜Â®Ã˜Â·Ã˜Â£ Ã˜Â§Ã™â€žÃ˜ÂªÃ˜Â¬Ã™â€¦Ã™Å Ã˜Â¹
static unsigned long recordingStartTime = 0;
static size_t bufferReadPos = 0;
static size_t bufferWritePos = 0;
static size_t audioSamplesRecorded = 0;

// Audio enhancement global state
NoiseProfile noiseProfile{};
AGCState agcState{};
VADMetrics vadMetrics{};

// Enhanced audio processing buffers
static int16_t* processingBuffer = nullptr;
static float* fftBuffer = nullptr;
static bool enhancementsInitialized = false;

// I2S and task management
static bool i2s0_installed = false;
static TaskHandle_t hPlaybackTask = nullptr;
static TaskHandle_t hCaptureTask = nullptr;
static uint8_t* capture_rb = nullptr;
static uint8_t* playback_rb = nullptr;

// PAM8403 Audio System Variables - using config.h definitions
static int masterVolume = 50;    // Master volume 0-100
static bool dacInitialized = false;

// Ã¢Å“â€¦ I2S and RingBuffer variables (Global/Static)
static SemaphoreHandle_t i2s_mutex = nullptr;
static RingbufHandle_t   audio_capture_ringbuf = nullptr;
static RingbufHandle_t   audio_playback_ringbuf = nullptr;
static TaskHandle_t      audio_capture_task_handle = nullptr;
static TaskHandle_t      audio_playback_task_handle = nullptr;
static TaskHandle_t      websocket_send_task_handle = nullptr;
static volatile bool     i2s_tasks_running = false;

// Memory management functions
static bool allocateAudioBuffer() {
  if (audioBuffer != nullptr) {
    free(audioBuffer);
    audioBuffer = nullptr;
  }
  
  audioBufferSize = SAMPLE_RATE * RECORD_TIME * 2; // 16-bit samples
  audioBuffer = (uint8_t*)malloc(audioBufferSize);
  
  if (audioBuffer == nullptr) {
    Serial.println("Ã¢ÂÅ’ Failed to allocate audio buffer!");
    audioBufferSize = 0;
    setAudioState(AUDIO_ERROR);
    return false;
  }
  
  Serial.printf("Ã¢Å“â€¦ Audio buffer allocated: %d bytes\n", audioBufferSize);
  return true;
}

static void deallocateAudioBuffer() {
  if (audioBuffer != nullptr) {
    free(audioBuffer);
    audioBuffer = nullptr;
    audioBufferSize = 0;
    audioBufferIndex = 0;
    Serial.println("Ã¢Å“â€¦ Audio buffer deallocated");
  }
}

// Enhanced initialization with proper error handling
void initAudio() {
  Serial.println("Ã°Å¸Å½Â¤ Initializing audio system...");
  
  // Cleanup any existing resources
  cleanupAudio();
  
  // Allocate audio buffer with error checking
  if (!allocateAudioBuffer()) {
    Serial.println("Ã¢ÂÅ’ Audio initialization failed - buffer allocation error");
    return;
  }
  
  // Initialize I2S with error checking
  if (!setupI2S()) {
    Serial.println("Ã¢ÂÅ’ Audio initialization failed - I2S setup error");
    deallocateAudioBuffer();
    return;
  }
  
  // Initialize audio enhancements
  initAudioEnhancements();
  
  currentAudioState = AUDIO_IDLE;
  audioInitialized = true;
  
  Serial.printf("Ã¢Å“â€¦ Audio system initialized successfully! Buffer: %d bytes\n", audioBufferSize);
}

bool setupI2S() {
  Serial.println("Ã°Å¸Å½Â¤ Setting up production I2S with ring buffers...");
  
  // Create I2S mutex for thread safety
  i2s_mutex = xSemaphoreCreateMutex();
  if (i2s_mutex == nullptr) {
    Serial.println("Ã¢ÂÅ’ Failed to create I2S mutex");
    return false;
  }
  
  // Create ring buffer for audio capture (use fixed, modest size for stability)
  audio_capture_ringbuf = xRingbufferCreate(CAPTURE_RING_BYTES, RINGBUF_TYPE_BYTEBUF);
#if FEATURE_AUDIO_PLAYBACK
  audio_playback_ringbuf = xRingbufferCreate(PLAYBACK_RING_BYTES, RINGBUF_TYPE_BYTEBUF);
#else
  audio_playback_ringbuf = nullptr;
#endif
  
#if FEATURE_AUDIO_PLAYBACK
  if (!audio_capture_ringbuf || !audio_playback_ringbuf) {
    Serial.println("Ã¢ÂÅ’ Failed to create audio ring buffers");
    return false;
  }
#else
  if (!audio_capture_ringbuf) {
    Serial.println("Ã¢ÂÅ’ Failed to create audio ring buffers");
    return false;
  }
#endif
  
  // Ã¢Å“â€¦ Configure I2S without C++17 designated initializers - zero then assign
  i2s_config_t cfg{};  // Ã˜ÂªÃ˜ÂµÃ™ÂÃ™Å Ã˜Â±
  cfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX
#if FEATURE_AUDIO_PLAYBACK
            | I2S_MODE_TX
#endif
#if FEATURE_AUDIO_ADC_INPUT
            | I2S_MODE_ADC_BUILT_IN
#endif
  );
  cfg.sample_rate = SAMPLE_RATE;
  cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  cfg.channel_format = I2S_CHANNEL_FMT_ONLY_LEFT;
  cfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  cfg.intr_alloc_flags = ESP_INTR_FLAG_LEVEL2;
  // Ã¢Å“â€¦ Ã˜Â§Ã™â€žÃ˜Â­Ã™â€ž: Ã˜ÂªÃ˜Â­Ã˜Â³Ã™Å Ã™â€  Ã™â€žÃ™â€žÃ™â‚¬ real-time
  cfg.dma_buf_count = 4;     // Ã™Æ’Ã˜Â§Ã™ÂÃ™Å  Ã™â€žÃ™â€žÃ™â‚¬ real-time  
  cfg.dma_buf_len = 1024;    // Ã™â€¦Ã™â€ Ã˜Â§Ã˜Â³Ã˜Â¨ Ã™â€žÃ™â€žÃ™â‚¬ streaming
  cfg.use_apll = true;       // Ã˜Â¯Ã™â€šÃ˜Â© Ã˜Â£Ã˜Â¹Ã™â€žÃ™â€° Ã™â€žÃ™â€žÃ˜ÂµÃ™Ë†Ã˜Âª
  cfg.tx_desc_auto_clear = true;
  cfg.fixed_mclk = 0;
#if defined(I2S_MCLK_MULTIPLE_256)
  cfg.mclk_multiple = I2S_MCLK_MULTIPLE_256;
#endif
#if defined(I2S_BITS_PER_CHAN_16BIT)
  cfg.bits_per_chan = I2S_BITS_PER_CHAN_16BIT;
#endif

#if !FEATURE_AUDIO_ADC_INPUT
  // Using internal DAC, no external I2S pins needed

  // Uninstall current driver
  esp_err_t result = i2s_driver_uninstall(I2S_NUM_0);
  if (result != ESP_OK) {
    Serial.printf("Ã¢Å¡Â Ã¯Â¸Â I2S uninstall warning: %s\n", esp_err_to_name(result));
  }
  
  // Install for output
  result = i2s_driver_install(I2S_NUM_0, &cfg, 0, NULL);
  if (result != ESP_OK) {
    Serial.printf("Ã¢ÂÅ’ I2S output driver installation failed: %s\n", esp_err_to_name(result));
// Route audio to internal DAC (GPIO25) for analog amplifier
i2s_set_pin(I2S_NUM_0, NULL);
i2s_set_dac_mode(I2S_DAC_CHANNEL_LEFT_EN);
dac_output_enable(DAC_CHANNEL_1);
    return false;
  }
  
  result = i2s_set_pin(I2S_NUM_0, &pins);
  if (result != ESP_OK) {
    Serial.printf("Ã¢ÂÅ’ I2S output pin configuration failed: %s\n", esp_err_to_name(result));
    return false;
  }
  
#endif
  return true;
}

// Minimal, safe implementations to satisfy linker and allow build.
// These can be expanded to full functionality later.
void cleanupAudio() {
  // Stop any tasks and free buffers if they exist
  audioInitialized = false;
  recordingActive = false;

  // Disable I2S ADC/DAC and uninstall driver if present
  i2s_adc_disable(I2S_NUM_0);
  i2s_driver_uninstall(I2S_NUM_0);

  // Free capture/playback ring buffers
  if (audio_capture_ringbuf) {
    vRingbufferDelete(audio_capture_ringbuf);
    audio_capture_ringbuf = nullptr;
  }
  if (audio_playback_ringbuf) {
    vRingbufferDelete(audio_playback_ringbuf);
    audio_playback_ringbuf = nullptr;
  }

  // Free main audio buffer
  deallocateAudioBuffer();
}

void playAudioResponse(uint8_t* audioData, size_t length) {
  // Stub: no-op playback. Integrate with I2S/DAC if needed.
  (void)audioData;
  (void)length;
  Serial.println("playAudioResponse stub called (no playback)");
}

void startRealTimeStreaming() {
  // Stub: mark state as streaming
  setAudioState(AUDIO_STREAMING);
  Serial.println("startRealTimeStreaming stub called");
}

void stopRealTimeStreaming() {
  // Stub: mark state as idle
  setAudioState(AUDIO_IDLE);
  Serial.println("stopRealTimeStreaming stub called");
}

void sendAudioToServer() {
  if (!isConnected || audioBufferIndex == 0 || audioBuffer == nullptr) {
    Serial.println("Ã¢Å¡Â Ã¯Â¸Â Cannot send audio: not connected or no data");
    return;
  }
  
  Serial.println("Ã°Å¸â€œÂ¤ Sending audio to server...");
  
  setAudioState(AUDIO_SENDING);
  
  // Visual feedback
  // Audio-only warning - no yellow LED needed
  
  // Apply audio compression before sending
  size_t compressedSize = 0;
  uint8_t* compressedData = compressAudioData(audioBuffer, audioBufferIndex, &compressedSize);
  
  if (compressedData != nullptr && compressedSize > 0) {
    Serial.printf("Ã°Å¸â€”Å“Ã¯Â¸Â Audio compressed: %d -> %d bytes (%.1f%% reduction)\n", 
                  audioBufferIndex, compressedSize, 
                  100.0 * (audioBufferIndex - compressedSize) / audioBufferIndex);
    
    // Send compressed audio data via WebSocket
    sendAudioData(compressedData, compressedSize);
    
    // Free compressed data
    free(compressedData);
  } else {
    Serial.println("Ã¢Å¡Â Ã¯Â¸Â Compression failed, sending uncompressed data");
    // Send original data as fallback
    sendAudioData(audioBuffer, audioBufferIndex);
  }
  
  setAudioState(AUDIO_IDLE);
  // No LEDs to clear in audio-only teddy bear
  
  Serial.println("Ã°Å¸â€œÂ¤ Audio sent to server");
}

size_t readAudioData(uint8_t* buffer, size_t bufferSize) {
  // Enhanced memory bounds checking
  if (buffer == nullptr) {
    Serial.println("Ã¢ÂÅ’ readAudioData: null buffer pointer");
    setAudioState(AUDIO_ERROR);
    return 0;
  }
  
  if (bufferSize == 0 || bufferSize > MAX_BUFFER_SIZE) {
    Serial.printf("Ã¢ÂÅ’ readAudioData: invalid buffer size %d (max: %d)\n", bufferSize, MAX_BUFFER_SIZE);
    setAudioState(AUDIO_ERROR);
    return 0;
  }
  
  // Check available heap before proceeding
  if (ESP.getFreeHeap() < MIN_FREE_HEAP) {
    Serial.printf("Ã¢ÂÅ’ readAudioData: insufficient memory %d bytes (min: %d)\n", ESP.getFreeHeap(), MIN_FREE_HEAP);
    setAudioState(AUDIO_ERROR);
    return 0;
  }
  
  size_t bytesRead = 0;
  // Use timeout instead of portMAX_DELAY to prevent blocking
  TickType_t timeout = pdMS_TO_TICKS(100); // 100ms timeout
  esp_err_t result = i2s_read(I2S_NUM_0, buffer, bufferSize, &bytesRead, timeout);
  
  if (result == ESP_ERR_TIMEOUT) {
    // Timeout is not critical, just return 0 bytes
    return 0;
  }
  
  if (result != ESP_OK) {
    Serial.printf("Ã¢ÂÅ’ I2S read error: %s\n", esp_err_to_name(result));
    setAudioState(AUDIO_ERROR);
    return 0;
  }
  
  // Validate read data
  if (bytesRead > bufferSize) {
    Serial.printf("Ã¢ÂÅ’ I2S read overflow: read %d > buffer %d\n", bytesRead, bufferSize);
    setAudioState(AUDIO_ERROR);
    return 0;
  }
  
  return bytesRead;
}

void writeAudioData(uint8_t* buffer, size_t bufferSize) {
  if (buffer == nullptr || bufferSize == 0) {
    return;
  }
  
  size_t bytesWritten = 0;
  esp_err_t result = i2s_write(I2S_NUM_0, buffer, bufferSize, &bytesWritten, portMAX_DELAY);
  
  if (result != ESP_OK) {
    Serial.printf("Ã¢ÂÅ’ I2S write error: %s\n", esp_err_to_name(result));
    setAudioState(AUDIO_ERROR);
  }
}

void setAudioState(AudioState state) {
  currentAudioState = state;
  
  const char* stateNames[] = {"IDLE", "RECORDING", "PLAYING", "SENDING", "ERROR"};
  Serial.printf("Ã°Å¸Å½Âµ Audio state: %s\n", stateNames[state]);
}

AudioState getAudioState() {
  return currentAudioState;
}

void printAudioInfo() {
  Serial.println("=== Ã°Å¸Å½Âµ Audio System Info ===");
  Serial.printf("Initialized: %s\n", audioInitialized ? "Yes" : "No");
  Serial.printf("Sample Rate: %d Hz\n", SAMPLE_RATE);
  Serial.printf("Bits per Sample: %d\n", SAMPLE_BITS);
  Serial.printf("Record Time: %d seconds\n", RECORD_TIME);
  Serial.printf("Buffer Size: %d bytes\n", BUFFER_SIZE);
  Serial.printf("Audio Buffer Size: %d bytes\n", audioBufferSize);
  Serial.printf("Current State: %d\n", currentAudioState);
  Serial.printf("Buffer Index: %d\n", audioBufferIndex);
  Serial.printf("Free Heap: %d bytes\n", ESP.getFreeHeap());
  Serial.println("============================");
}

// Simple audio compression using Run-Length Encoding for silence detection
uint8_t* compressAudioData(uint8_t* data, size_t dataSize, size_t* compressedSize) {
  if (data == nullptr || dataSize == 0 || compressedSize == nullptr) {
    return nullptr;
  }
  
  // Check memory availability
  if (ESP.getFreeHeap() < MIN_FREE_HEAP) {
    Serial.println("Ã¢ÂÅ’ Insufficient memory for compression");
    return nullptr;
  }
  
  // Allocate temporary buffer (worst case: 2x original size)
  uint8_t* compressed = (uint8_t*)malloc(dataSize * 2);
  if (compressed == nullptr) {
    Serial.println("Ã¢ÂÅ’ Failed to allocate compression buffer");
    return nullptr;
  }
  
  size_t compIndex = 0;
  size_t i = 0;
  const uint8_t SILENCE_THRESHOLD = 5; // Adjust based on noise floor
  
  while (i < dataSize) {
    uint8_t currentByte = data[i];
    
    // Check for silence (values near zero)
    if (abs((int8_t)currentByte) <= SILENCE_THRESHOLD) {
      // Count consecutive silent samples
      size_t silenceCount = 0;
      size_t startPos = i;
      
      while (i < dataSize && abs((int8_t)data[i]) <= SILENCE_THRESHOLD && silenceCount < 255) {
        silenceCount++;
        i++;
      }
      
      if (silenceCount >= 3) { // Only compress if we have at least 3 silent samples
        // Write compression marker and count
        compressed[compIndex++] = 0xFF; // Compression marker
        compressed[compIndex++] = (uint8_t)silenceCount;
        compressed[compIndex++] = 0x00; // Silence value
      } else {
        // Copy original data if compression isn't beneficial
        for (size_t j = startPos; j < i; j++) {
          compressed[compIndex++] = data[j];
        }
      }
    } else {
      // Copy non-silent data as-is
      compressed[compIndex++] = currentByte;
      i++;
    }
  }
  
  // Shrink buffer to actual size
  uint8_t* finalCompressed = (uint8_t*)realloc(compressed, compIndex);
  if (finalCompressed == nullptr) {
    // Realloc failed, use original buffer
    finalCompressed = compressed;
  }
  
  *compressedSize = compIndex;
  return finalCompressed;
}

void decompressAudioData(uint8_t* compressedData, size_t compressedSize, uint8_t* outputData, size_t outputSize) {
  if (compressedData == nullptr || outputData == nullptr || compressedSize == 0 || outputSize == 0) {
    return;
  }
  
  size_t compIndex = 0;
  size_t outIndex = 0;
  
  while (compIndex < compressedSize && outIndex < outputSize) {
    if (compressedData[compIndex] == 0xFF && compIndex + 2 < compressedSize) {
      // Decompression marker found
      uint8_t count = compressedData[compIndex + 1];
      uint8_t value = compressedData[compIndex + 2];
      
      // Expand compressed data
      for (uint8_t i = 0; i < count && outIndex < outputSize; i++) {
        outputData[outIndex++] = value;
      }
      
      compIndex += 3;
    } else {
      // Copy uncompressed data
      outputData[outIndex++] = compressedData[compIndex++];
    }
  }
}

// =============================================================================
// AUDIO ENHANCEMENT IMPLEMENTATIONS
// =============================================================================

void initAudioEnhancements() {
  Serial.println("Ã°Å¸Å½Âµ Initializing audio enhancements...");
  
  // Allocate processing buffer
  size_t sampleCount = SAMPLE_RATE * RECORD_TIME; // 16-bit samples
  processingBuffer = (int16_t*)malloc(sampleCount * sizeof(int16_t));
  
  if (processingBuffer == nullptr) {
    Serial.println("Ã¢ÂÅ’ Failed to allocate audio processing buffer");
    return;
  }
  
  // Allocate FFT buffer for spectral analysis
  fftBuffer = (float*)malloc(512 * sizeof(float)); // 512-point FFT
  
  if (fftBuffer == nullptr) {
    Serial.println("Ã¢ÂÅ’ Failed to allocate FFT buffer");
    free(processingBuffer);
    processingBuffer = nullptr;
    return;
  }
  
  // Initialize noise profile
  memset(&noiseProfile, 0, sizeof(NoiseProfile));
  for (int i = 0; i < 256; i++) {
    noiseProfile.spectral_floor[i] = 0.1f; // Initial noise floor estimate
  }
  
  // Initialize AGC state
  initAGC();
  
  // Initialize VAD metrics
  vadMetrics.state = VAD_UNKNOWN;
  vadMetrics.energy = 0.0f;
  vadMetrics.zero_crossing_rate = 0.0f;
  vadMetrics.speech_frames = 0;
  vadMetrics.silence_frames = 0;
  
  enhancementsInitialized = true;
  Serial.println("Ã¢Å“â€¦ Audio enhancements initialized successfully");
}

void cleanupAudioEnhancements() {
  if (processingBuffer != nullptr) {
    free(processingBuffer);
    processingBuffer = nullptr;
  }
  
  if (fftBuffer != nullptr) {
    free(fftBuffer);
    fftBuffer = nullptr;
  }
  
  enhancementsInitialized = false;
  Serial.println("Ã¢Å“â€¦ Audio enhancements cleaned up");
}

// =============================================================================
// NOISE CANCELLATION IMPLEMENTATIONS
// =============================================================================

void calibrateNoiseProfile(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount == 0) return;
  
  // Calculate noise level from samples (assuming silence)
  float noiseSum = 0.0f;
  for (size_t i = 0; i < sampleCount; i++) {
    noiseSum += abs(samples[i]);
  }
  
  float avgNoise = noiseSum / sampleCount;
  
  // Update noise profile with exponential smoothing
  if (noiseProfile.calibration_samples == 0) {
    noiseProfile.noise_estimate = avgNoise;
  } else {
    noiseProfile.noise_estimate = noiseProfile.noise_estimate * 0.9f + avgNoise * 0.1f;
  }
  
  noiseProfile.calibration_samples++;
  
  // Mark profile as ready after sufficient calibration
  if (noiseProfile.calibration_samples >= 10) {
    noiseProfile.profile_ready = true;
  }
  
  Serial.printf("Ã°Å¸Å½Å¡Ã¯Â¸Â Noise calibration: level=%.1f, samples=%d\n", 
    noiseProfile.noise_estimate, noiseProfile.calibration_samples);
}

void applyNoiseReduction(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount == 0 || !enhancementsInitialized) return;
  
  // Apply simple noise gate
  applyNoiseGate(samples, sampleCount);
  
  // Apply low-pass filter to reduce high-frequency noise
  applyLowPassFilter(samples, sampleCount);
  
  // Apply spectral subtraction if noise profile is ready
  if (noiseProfile.profile_ready) {
    applySpectralSubtraction(samples, sampleCount);
  }
}

void applyNoiseGate(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount == 0) return;
  
  for (size_t i = 0; i < sampleCount; i++) {
    if (abs(samples[i]) < NOISE_GATE_THRESHOLD) {
      // Gradually reduce to zero instead of hard cut-off
      samples[i] = (int16_t)(samples[i] * 0.1f);
    }
  }
}

void applySpectralSubtraction(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount == 0 || !noiseProfile.profile_ready) return;
  
  // Simple frequency domain noise reduction
  // This is a simplified implementation - full spectral subtraction would require FFT
  
  // Apply noise floor subtraction in time domain
  for (size_t i = 0; i < sampleCount; i++) {
    float sample = (float)samples[i];
    float noiseThreshold = noiseProfile.noise_estimate * SPECTRAL_SUBTRACTION_ALPHA;
    
    if (abs(sample) > noiseThreshold) {
      // Preserve signal above noise floor
      if (sample > 0) {
        sample = max(0.0f, sample - noiseThreshold);
      } else {
        sample = min(0.0f, sample + noiseThreshold);
      }
    } else {
      // Attenuate noise floor
      sample *= 0.2f;
    }
    
    samples[i] = (int16_t)constrain(sample, -32767, 32767);
  }
}

// =============================================================================
// VOICE ACTIVITY DETECTION IMPLEMENTATIONS
// =============================================================================

VADState detectVoiceActivity(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount == 0) return VAD_UNKNOWN;
  
  // Calculate frame energy
  vadMetrics.energy = calculateFrameEnergy(samples, sampleCount);
  
  // Calculate zero crossing rate
  vadMetrics.zero_crossing_rate = calculateZeroCrossingRate(samples, sampleCount);
  
  // Voice activity decision based on energy and zero crossing rate
  bool energyTest = vadMetrics.energy > VAD_ENERGY_THRESHOLD;
  bool zcrTest = vadMetrics.zero_crossing_rate > 0.1f && vadMetrics.zero_crossing_rate < 0.8f;
  
  VADState newState;
  if (energyTest && zcrTest) {
    newState = VAD_SPEECH;
    vadMetrics.speech_frames++;
    vadMetrics.silence_frames = 0;
  } else {
    newState = VAD_SILENCE;
    vadMetrics.silence_frames++;
    vadMetrics.speech_frames = 0;
  }
  
  // Apply hysteresis to prevent rapid switching
  if (vadMetrics.state == VAD_SPEECH && newState == VAD_SILENCE) {
    if (vadMetrics.silence_frames < 5) { // Keep speech state for short silence
      newState = VAD_SPEECH;
    }
  } else if (vadMetrics.state == VAD_SILENCE && newState == VAD_SPEECH) {
    if (vadMetrics.speech_frames < 3) { // Require sustained speech
      newState = VAD_SILENCE;
    }
  }
  
  vadMetrics.state = newState;
  return newState;
}

float calculateFrameEnergy(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount == 0) return 0.0f;
  
  float energy = 0.0f;
  for (size_t i = 0; i < sampleCount; i++) {
    float sample = (float)samples[i] / 32768.0f; // Normalize
    energy += sample * sample;
  }
  
  return energy / sampleCount; // Average energy
}

float calculateZeroCrossingRate(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount < 2) return 0.0f;
  
  uint32_t crossings = 0;
  for (size_t i = 1; i < sampleCount; i++) {
    if ((samples[i] > 0 && samples[i-1] <= 0) || (samples[i] <= 0 && samples[i-1] > 0)) {
      crossings++;
    }
  }
  
  return (float)crossings / (sampleCount - 1);
}

bool isVoicePresent() {
  return vadMetrics.state == VAD_SPEECH;
}

// =============================================================================
// AUTOMATIC GAIN CONTROL IMPLEMENTATIONS
// =============================================================================

void initAGC() {
  agcState.current_gain = 1.0f;
  agcState.peak_level = 0.0f;
  agcState.rms_level = 0.0f;
  agcState.attack_time = 0.1f;   // Fast attack
  agcState.release_time = 0.9f;  // Slow release
  
  Serial.println("Ã°Å¸Å½Å¡Ã¯Â¸Â AGC initialized");
}

void applyAutomaticGainControl(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount == 0) return;
  
  // Calculate current audio levels
  float currentRMS = calculateRMSLevel(samples, sampleCount);
  float currentPeak = calculatePeakLevel(samples, sampleCount);
  
  // Update level trackers with smoothing
  agcState.rms_level = agcState.rms_level * 0.9f + currentRMS * 0.1f;
  agcState.peak_level = max(agcState.peak_level * 0.95f, currentPeak);
  
  // Calculate desired gain
  float targetGain = 1.0f;
  if (agcState.rms_level > 0.01f) {
    targetGain = (float)AGC_TARGET_LEVEL / (agcState.rms_level * 32768.0f);
  }
  
  // Limit gain range
  targetGain = constrain(targetGain, AGC_MIN_GAIN, AGC_MAX_GAIN);
  
  // Apply attack/release smoothing
  float alpha = (targetGain > agcState.current_gain) ? agcState.attack_time : agcState.release_time;
  agcState.current_gain = agcState.current_gain * (1.0f - alpha) + targetGain * alpha;
  
  // Apply gain to samples
  for (size_t i = 0; i < sampleCount; i++) {
    float sample = (float)samples[i] * agcState.current_gain;
    samples[i] = (int16_t)constrain(sample, -32767, 32767);
  }
}

float calculateRMSLevel(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount == 0) return 0.0f;
  
  float sum = 0.0f;
  for (size_t i = 0; i < sampleCount; i++) {
    float sample = (float)samples[i] / 32768.0f;
    sum += sample * sample;
  }
  
  return sqrt(sum / sampleCount);
}

float calculatePeakLevel(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount == 0) return 0.0f;
  
  float peak = 0.0f;
  for (size_t i = 0; i < sampleCount; i++) {
    float sample = abs((float)samples[i]) / 32768.0f;
    if (sample > peak) {
      peak = sample;
    }
  }
  
  return peak;
}

// =============================================================================
// AUDIO QUALITY OPTIMIZATION IMPLEMENTATIONS
// =============================================================================

void applyAudioEnhancements(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount == 0 || !enhancementsInitialized) return;
  
  unsigned long startTime = millis();
  
  // 1. Noise reduction
  applyNoiseReduction(samples, sampleCount);
  
  // 2. Voice Activity Detection (for adaptive processing)
  VADState vadState = detectVoiceActivity(samples, sampleCount);
  
  // 3. Apply AGC only during speech
  if (vadState == VAD_SPEECH) {
    applyAutomaticGainControl(samples, sampleCount);
  }
  
  // 4. Apply high-pass filter to remove DC offset and low-frequency noise
  applyHighPassFilter(samples, sampleCount);
  
  // 5. Apply dynamic range compression for better clarity
  applyDynamicRangeCompression(samples, sampleCount);
  
  // 6. Apply echo suppression
  applyEchoSuppression(samples, sampleCount);
  
  // Record processing latency
  uint32_t processingTime = millis() - startTime;
  if (processingTime > 10) { // Log if processing takes more than 10ms
    Serial.printf("Ã°Å¸Å½Âµ Audio enhancement latency: %dms\n", processingTime);
  }
  
  // Record latency for monitoring system
  recordAudioLatency(processingTime);
  
  // Performance monitoring integration (implement if needed)
  // if (performanceMonitoringEnabled) {
  //   // This would be called at different stages of audio processing
  //   // performanceMonitor.recordAudioCaptureEnd();
  // }
}

void applyLowPassFilter(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount < 2) return;
  
  // Simple IIR low-pass filter
  float prev = 0.0f;
  for (size_t i = 0; i < sampleCount; i++) {
    float current = (float)samples[i];
    float filtered = FILTER_ALPHA * prev + (1.0f - FILTER_ALPHA) * current;
    samples[i] = (int16_t)constrain(filtered, -32767, 32767);
    prev = filtered;
  }
}

void applyHighPassFilter(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount < 2) return;
  
  // Simple high-pass filter to remove DC offset
  const float hp_alpha = 0.98f;
  static float prev_input = 0.0f;
  static float prev_output = 0.0f;
  
  for (size_t i = 0; i < sampleCount; i++) {
    float input = (float)samples[i];
    float output = hp_alpha * prev_output + hp_alpha * (input - prev_input);
    
    samples[i] = (int16_t)constrain(output, -32767, 32767);
    
    prev_input = input;
    prev_output = output;
  }
}

void applyDynamicRangeCompression(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount == 0) return;
  
  const float threshold = 0.7f;  // Compression threshold
  const float ratio = 4.0f;      // Compression ratio
  
  for (size_t i = 0; i < sampleCount; i++) {
    float sample = (float)samples[i] / 32768.0f;
    float abs_sample = abs(sample);
    
    if (abs_sample > threshold) {
      float excess = abs_sample - threshold;
      float compressed_excess = excess / ratio;
      float new_abs = threshold + compressed_excess;
      
      sample = (sample > 0) ? new_abs : -new_abs;
    }
    
    samples[i] = (int16_t)(sample * 32768.0f);
  }
}

void applyEchoSuppression(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount == 0) return;
  
  // Simple echo suppression using adaptive filtering
  // This is a basic implementation - more sophisticated algorithms exist
  
  static int16_t delay_line[320]; // 20ms delay at 16kHz
  static int delay_index = 0;
  
  for (size_t i = 0; i < sampleCount; i++) {
    // Get delayed sample
    int16_t delayed_sample = delay_line[delay_index];
    
    // Apply echo cancellation (simple subtraction with attenuation)
    int16_t processed_sample = samples[i] - (delayed_sample / 4);
    
    // Store current sample in delay line
    delay_line[delay_index] = samples[i];
    delay_index = (delay_index + 1) % 320;
    
    samples[i] = processed_sample;
  }
}

// =============================================================================
// ENHANCED RECORDING WITH PROCESSING
// =============================================================================

void startEnhancedRecording() {
  if (!audioInitialized || !enhancementsInitialized || currentAudioState != AUDIO_IDLE) {
    Serial.println("Ã¢Å¡Â Ã¯Â¸Â Enhanced audio not ready for recording");
    setAudioState(AUDIO_ERROR);
    return;
  }
  
  Serial.println("Ã°Å¸Å½Â¤ Starting enhanced audio recording...");
  
  // Reset buffer safely
  audioBufferIndex = 0;
  memset(audioBuffer, 0, audioBufferSize);
  
  // Calibrate noise profile if not ready
  if (!noiseProfile.profile_ready && audioBufferSize >= 1024) {
    Serial.println("Ã°Å¸Å½Å¡Ã¯Â¸Â Calibrating noise profile...");
    // Record 0.5 seconds of ambient noise for calibration
    size_t calibrationSamples = SAMPLE_RATE / 2; // 0.5 seconds
    int16_t* calibrationBuffer = (int16_t*)malloc(calibrationSamples * sizeof(int16_t));
    
    if (calibrationBuffer != nullptr) {
      size_t samplesRead = 0;
      while (samplesRead < calibrationSamples) {
        uint8_t tempBuffer[BUFFER_SIZE];
        size_t bytesRead = readAudioData(tempBuffer, BUFFER_SIZE);
        
        if (bytesRead > 0) {
          size_t samples = bytesRead / 2; // 16-bit samples
          memcpy(calibrationBuffer + samplesRead, tempBuffer, min(bytesRead, (calibrationSamples - samplesRead) * 2));
          samplesRead += samples;
        }
      }
      
      calibrateNoiseProfile(calibrationBuffer, calibrationSamples);
      free(calibrationBuffer);
    }
  }
  
  // Set state
  setAudioState(AUDIO_RECORDING);
  recordingActive = true;
  
  // Visual feedback
  // Audio-only feedback - no LEDs in teddy bear
  
  // Record with enhanced processing
  unsigned long startTime = millis();
  size_t bytesRead = 0;
  
  while (millis() - startTime < RECORD_TIME * 1000 && recordingActive && audioInitialized) {
    uint8_t tempBuffer[BUFFER_SIZE];
    size_t bytesToRead = min((size_t)BUFFER_SIZE, audioBufferSize - audioBufferIndex);
    
    if (bytesToRead > 0) {
      bytesRead = readAudioData(tempBuffer, bytesToRead);
      
      if (bytesRead > 0 && audioBufferIndex + bytesRead <= audioBufferSize) {
        // Process audio frame with enhancements
        processAudioFrame((int16_t*)tempBuffer, bytesRead / 2);
        
        memcpy(audioBuffer + audioBufferIndex, tempBuffer, bytesRead);
        audioBufferIndex += bytesRead;
      } else {
        Serial.println("Ã¢Å¡Â Ã¯Â¸Â Buffer overflow prevented");
        break;
      }
    } else {
      Serial.println("Ã¢Å¡Â Ã¯Â¸Â Buffer full, stopping recording");
      break;
    }
    
    esp_task_wdt_reset(); // Ã¢Å“â€¦ Feed watchdog during enhanced recording
    delay(10);
  }
  
  stopRecording();
  
  Serial.printf("Ã°Å¸Å½Â¤ Enhanced recording complete: %d bytes\n", audioBufferIndex);
  
  // Send to server if data is available
  if (audioBufferIndex > 0) {
    sendAudioToServer();
  }
}

void processAudioFrame(int16_t* samples, size_t sampleCount) {
  if (samples == nullptr || sampleCount == 0 || !enhancementsInitialized) return;
  
  // Apply all audio enhancements
  applyAudioEnhancements(samples, sampleCount);
}

// =============================================================================
// AUDIO ANALYSIS AND METRICS
// =============================================================================

float getSignalToNoiseRatio() {
  if (!noiseProfile.profile_ready || agcState.rms_level == 0.0f) {
    return 0.0f;
  }
  
  float signalLevel = agcState.rms_level * 32768.0f;
  float noiseLevel = noiseProfile.noise_estimate;
  
  if (noiseLevel > 0.0f) {
    return 20.0f * log10(signalLevel / noiseLevel); // SNR in dB
  }
  
  return 100.0f; // Very high SNR
}

float getCurrentAudioQuality() {
  float quality = 0.0f;
  
  // Factor 1: Signal-to-Noise Ratio (0-40 points)
  float snr = getSignalToNoiseRatio();
  quality += constrain(snr, 0.0f, 40.0f);
  
  // Factor 2: Voice Activity Detection (0-30 points)
  if (vadMetrics.state == VAD_SPEECH) {
    quality += 30.0f;
  } else if (vadMetrics.state == VAD_SILENCE) {
    quality += 10.0f; // Some points for clean silence
  }
  
  // Factor 3: AGC Stability (0-20 points)
  if (agcState.current_gain > 0.5f && agcState.current_gain < 2.0f) {
    quality += 20.0f; // Good gain range
  } else {
    quality += 10.0f * (1.0f - abs(log2(agcState.current_gain))); // Penalty for extreme gains
  }
  
  // Factor 4: Audio Level (0-10 points)
  if (agcState.rms_level > 0.1f && agcState.rms_level < 0.8f) {
    quality += 10.0f;
  }
  
  return constrain(quality, 0.0f, 100.0f);
}

void printAudioEnhancementStats() {
  Serial.println("=== Ã°Å¸Å½Âµ Audio Enhancement Stats ===");
  Serial.printf("Enhancements Initialized: %s\n", enhancementsInitialized ? "Yes" : "No");
  
  // Noise Profile Stats
  Serial.printf("Noise Profile Ready: %s\n", noiseProfile.profile_ready ? "Yes" : "No");
  Serial.printf("Noise Level: %.1f\n", noiseProfile.noise_estimate);
  Serial.printf("Calibration Samples: %d\n", noiseProfile.calibration_samples);
  
  // AGC Stats
  Serial.printf("Current AGC Gain: %.2fx\n", agcState.current_gain);
  Serial.printf("RMS Level: %.3f\n", agcState.rms_level);
  Serial.printf("Peak Level: %.3f\n", agcState.peak_level);
  
  // VAD Stats
  Serial.printf("VAD State: %s\n", 
    vadMetrics.state == VAD_SPEECH ? "SPEECH" : 
    vadMetrics.state == VAD_SILENCE ? "SILENCE" : "UNKNOWN");
  Serial.printf("Frame Energy: %.3f\n", vadMetrics.energy);
  Serial.printf("Zero Crossing Rate: %.3f\n", vadMetrics.zero_crossing_rate);
  
  // Quality Metrics
  Serial.printf("Signal-to-Noise Ratio: %.1f dB\n", getSignalToNoiseRatio());
  Serial.printf("Audio Quality Score: %.1f%%\n", getCurrentAudioQuality());
  
  Serial.println("===================================");
}

// ======================== PAM8403 Audio System Implementation ========================

bool initAudioSystem() {
    Serial.println("Ã°Å¸â€Å  Initializing Audio with PAM8403 Amplifier...");
    
    // Ã˜ÂªÃ™ÂÃ˜Â¹Ã™Å Ã™â€ž DAC channels
    dac_output_enable(DAC_CHANNEL_1);  // AUDIO_OUT_LEFT
    dac_output_enable(DAC_CHANNEL_2);  // AUDIO_OUT_RIGHT
    
    // Ã˜ÂªÃ˜Â¹Ã™Å Ã™Å Ã™â€  Ã™â€¦Ã˜Â³Ã˜ÂªÃ™Ë†Ã™â€° Ã™â€¦Ã™â€ Ã˜Â®Ã™ÂÃ˜Â¶ Ã˜Â£Ã™Ë†Ã™â€žÃ˜Â§Ã™â€¹ Ã™â€žÃ˜ÂªÃ˜Â¬Ã™â€ Ã˜Â¨ Ã˜Â§Ã™â€žÃ™â‚¬ pop
    dac_output_voltage(DAC_CHANNEL_1, 128);  // Ã™â€¦Ã™â€ Ã˜ÂªÃ˜ÂµÃ™Â Ã˜Â§Ã™â€žÃ™â€šÃ™Å Ã™â€¦Ã˜Â© (0-255)
    dac_output_voltage(DAC_CHANNEL_2, 128);
    
    delay(50);  // Ã˜Â§Ã™â€ Ã˜ÂªÃ˜Â¸Ã˜Â§Ã˜Â± Ã˜Â§Ã˜Â³Ã˜ÂªÃ™â€šÃ˜Â±Ã˜Â§Ã˜Â±
    
    dacInitialized = true;
    Serial.println("Ã¢Å“â€¦ Audio system with PAM8403 initialized");
    return true;
}

void playTone(int frequency, int duration) {
    if (!dacInitialized) {
        Serial.println("Ã¢ÂÅ’ DAC not initialized, cannot play tone");
        return;
    }
    
    Serial.printf("Ã°Å¸Å½Âµ Playing tone %dHz for %dms\n", frequency, duration);
    
    // const int sampleRate = 8000;  // sample rate Ã™â€¦Ã™â€ Ã˜Â®Ã™ÂÃ˜Â¶ Ã™â€žÃ™â€žÃ™â‚¬ DAC (unused)
    const float amplitude = 50.0; // Ã˜ÂªÃ™â€šÃ™â€žÃ™Å Ã™â€ž Ã˜Â§Ã™â€žÃ™â€šÃ™Ë†Ã˜Â© Ã™â€žÃ˜ÂªÃ˜Â¬Ã™â€ Ã˜Â¨ Ã˜Â§Ã™â€žÃ˜ÂªÃ˜Â´Ã™Ë†Ã™Å Ã™â€¡
    
    unsigned long startTime = millis();
    unsigned long currentTime = startTime;
    
    while ((currentTime - startTime) < duration) {
        // Ã˜Â­Ã˜Â³Ã˜Â§Ã˜Â¨ Ã˜Â§Ã™â€žÃ™â€¦Ã™Ë†Ã˜Â¬Ã˜Â©
        float timeInSeconds = (currentTime - startTime) / 1000.0;
        float sampleValue = sin(2.0 * PI * frequency * timeInSeconds) * amplitude + 128;
        
        // Ã˜ÂªÃ˜Â­Ã˜Â¯Ã™Å Ã˜Â¯ Ã˜Â§Ã™â€žÃ™â€šÃ™Å Ã™â€¦ Ã˜Â¶Ã™â€¦Ã™â€  Ã™â€ Ã˜Â·Ã˜Â§Ã™â€š DAC (0-255)
        uint8_t dacValue = constrain((int)sampleValue, 0, 255);
        
        // Ã˜Â¥Ã˜Â±Ã˜Â³Ã˜Â§Ã™â€ž Ã™â€žÃ™â€žÃ™â€šÃ™â€ Ã™Ë†Ã˜Â§Ã˜Âª
        dac_output_voltage(DAC_CHANNEL_1, dacValue);
        dac_output_voltage(DAC_CHANNEL_2, dacValue);
        
        // Ã˜ÂªÃ˜Â£Ã˜Â®Ã™Å Ã˜Â± Ã™â€žÃ™â€žÃ™â‚¬ sample rate
        delayMicroseconds(125);  // 1/8000 second = 125 microseconds
        
        currentTime = millis();
    }
    
    // Ã˜Â¹Ã™Ë†Ã˜Â¯Ã˜Â© Ã™â€žÃ™â€žÃ˜ÂµÃ™â€¦Ã˜Âª
    dac_output_voltage(DAC_CHANNEL_1, 128);
    dac_output_voltage(DAC_CHANNEL_2, 128);
}

void setMasterVolume(int volume) {
    // Ã˜Â§Ã™â€žÃ˜ÂªÃ˜Â­Ã™Æ’Ã™â€¦ Ã™ÂÃ™Å  Ã˜Â§Ã™â€žÃ˜Â­Ã˜Â¬Ã™â€¦ Ã˜Â¹Ã˜Â¨Ã˜Â± Ã˜ÂªÃ™â€šÃ™â€žÃ™Å Ã™â€ž amplitude
    // volume: 0-100
    masterVolume = constrain(volume, 0, 100);
    Serial.printf("Ã°Å¸â€Å  Volume set to %d%%\n", masterVolume);
}

void cleanupAudioSystem() {
    if (!dacInitialized) return;
    
    Serial.println("Ã°Å¸Â§Â¹ Cleaning audio system...");
    
    // Ã˜Â¹Ã™Ë†Ã˜Â¯Ã˜Â© Ã™â€žÃ™â€žÃ˜ÂµÃ™â€¦Ã˜Âª
    dac_output_voltage(DAC_CHANNEL_1, 128);
    dac_output_voltage(DAC_CHANNEL_2, 128);
    
    delay(100);
    
    // Ã˜Â¥Ã™Å Ã™â€šÃ˜Â§Ã™Â DAC
    dac_output_disable(DAC_CHANNEL_1);
    dac_output_disable(DAC_CHANNEL_2);
    
    dacInitialized = false;
    Serial.println("Ã¢Å“â€¦ Audio cleanup completed");
}

// Dummy task functions for compilation
void audio_playback_task(void* parameter) {
    Serial.println("Ã°Å¸â€Å  Audio playback task started");
    
    // Register with WDT
    esp_task_wdt_add(NULL);
    
    while (true) {
        // Feed WDT regularly
        esp_task_wdt_reset();
        
        // Playback logic here
        vTaskDelay(pdMS_TO_TICKS(100));
        
        // Monitor stack usage
        UBaseType_t stackLeft = uxTaskGetStackHighWaterMark(NULL);
        if (stackLeft < 512) {
            Serial.printf("Ã¢Å¡Â Ã¯Â¸Â Playback task low stack: %u bytes left\n", stackLeft);
        }
    }
}

void audio_capture_task(void* parameter) {
    Serial.println("Ã°Å¸Å½Â¤ Audio capture task started");
    
    // Register with WDT
    esp_task_wdt_add(NULL);
    
    while (true) {
        // Feed WDT regularly
        esp_task_wdt_reset();
        
        // Capture logic here
        vTaskDelay(pdMS_TO_TICKS(100));
        
        // Monitor stack usage
        UBaseType_t stackLeft = uxTaskGetStackHighWaterMark(NULL);
        if (stackLeft < 512) {
            Serial.printf("Ã¢Å¡Â Ã¯Â¸Â Capture task low stack: %u bytes left\n", stackLeft);
        }
    }
}

/**
 * Production-optimized audio initialization with memory management
 */
bool initProductionAudioSystem() {
    Serial.println("Ã°Å¸Å½Âµ Initializing production audio system...");
    
    // Print initial heap status
    Serial.printf("Ã°Å¸â€™Â¾ Initial heap: free=%u KB, largest=%u KB\n",
        heap_caps_get_free_size(MALLOC_CAP_8BIT) / 1024,
        heap_caps_get_largest_free_block(MALLOC_CAP_8BIT) / 1024);
    
    // Check minimum heap requirement
    if (heap_caps_get_largest_free_block(MALLOC_CAP_8BIT) < 40 * 1024) {
        Serial.println("Ã¢ÂÅ’ Insufficient heap for audio system (need 40KB)");
        return false;
    }
    
    // Allocate ring buffers first
    capture_rb = (uint8_t*)heap_caps_malloc(CAPTURE_RING_BYTES, MALLOC_CAP_8BIT);
    playback_rb = (uint8_t*)heap_caps_malloc(PLAYBACK_RING_BYTES, MALLOC_CAP_8BIT);
    
    if (!capture_rb || !playback_rb) {
        Serial.printf("Ã¢ÂÅ’ Ring buffer allocation failed. Free: %u KB\n",
            heap_caps_get_free_size(MALLOC_CAP_8BIT) / 1024);
        if (capture_rb) free(capture_rb);
        if (playback_rb) free(playback_rb);
        return false;
    }
    
    // Clean I2S if previously installed
    if (i2s0_installed) {
        i2s_driver_uninstall(I2S_NUM_0);
        i2s0_installed = false;
    }
    
    // Configure I2S with optimized settings
    i2s_config_t cfg = {
        .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_RX),
        .sample_rate = 16000,
        .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
        .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
        .communication_format = (i2s_comm_format_t)I2S_COMM_FORMAT_STAND_MSB,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
        .dma_buf_count = 6,
        .dma_buf_len = 256,
        .use_apll = false,
        .tx_desc_auto_clear = true,
        .fixed_mclk = 0
    };
    
    esp_err_t i2s_result = i2s_driver_install(I2S_NUM_0, &cfg, 0, nullptr);
    if (i2s_result != ESP_OK) {
        Serial.printf("Ã¢ÂÅ’ I2S install failed: %d\n", i2s_result);
        free(capture_rb);
        free(playback_rb);
        return false;
    }
    i2s0_installed = true;
    
    // Print heap after I2S installation
    Serial.printf("Ã°Å¸â€™Â¾ After I2S: free=%u KB, largest=%u KB\n",
        heap_caps_get_free_size(MALLOC_CAP_8BIT) / 1024,
        heap_caps_get_largest_free_block(MALLOC_CAP_8BIT) / 1024);
    
    // Create playback task first (higher priority for audio output)
    BaseType_t playbackOk = xTaskCreatePinnedToCore(
        audio_playback_task, "aud_play",
        6144, nullptr, AUDIO_PLAYBACK_PRIORITY, &hPlaybackTask, 1);
    
    if (playbackOk != pdPASS) {
        Serial.printf("Ã¢ÂÅ’ Playback task creation failed. Free: %u KB, Largest: %u KB\n",
            heap_caps_get_free_size(MALLOC_CAP_8BIT) / 1024,
            heap_caps_get_largest_free_block(MALLOC_CAP_8BIT) / 1024);
        
        // Cleanup
        i2s_driver_uninstall(I2S_NUM_0);
        i2s0_installed = false;
        free(capture_rb);
        free(playback_rb);
        return false;
    }
    
    // Create capture task
    BaseType_t captureOk = xTaskCreatePinnedToCore(
        audio_capture_task, "aud_cap",
        4096, nullptr, AUDIO_CAPTURE_PRIORITY, &hCaptureTask, 1);
    
    if (captureOk != pdPASS) {
        Serial.printf("Ã¢ÂÅ’ Capture task creation failed. Free: %u KB, Largest: %u KB\n",
            heap_caps_get_free_size(MALLOC_CAP_8BIT) / 1024,
            heap_caps_get_largest_free_block(MALLOC_CAP_8BIT) / 1024);
        
        // Cleanup
        vTaskDelete(hPlaybackTask);
        hPlaybackTask = nullptr;
        i2s_driver_uninstall(I2S_NUM_0);
        i2s0_installed = false;
        free(capture_rb);
        free(playback_rb);
        return false;
    }
    
    // Print final heap status
    Serial.printf("Ã°Å¸â€™Â¾ Final heap: free=%u KB, largest=%u KB\n",
        heap_caps_get_free_size(MALLOC_CAP_8BIT) / 1024,
        heap_caps_get_largest_free_block(MALLOC_CAP_8BIT) / 1024);
    
    Serial.printf("Ã¢Å“â€¦ Audio tasks created: Playback HW=%u, Capture HW=%u\n",
        uxTaskGetStackHighWaterMark(hPlaybackTask),
        uxTaskGetStackHighWaterMark(hCaptureTask));
    
    audioInitialized = true;
    return true;
}
