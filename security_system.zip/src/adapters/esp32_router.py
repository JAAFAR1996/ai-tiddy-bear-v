"""
ESP32 WebSocket Endpoint for AI Teddy Bear
=========================================
Production-ready WebSocket endpoint for ESP32 devices with separated public/private routes.
"""

import logging
from fastapi import (
    APIRouter,
    WebSocket,
    WebSocketDisconnect,
    Query,
    HTTPException,
    Depends,
    Response,
    Request,
)
from fastapi.security import HTTPBearer
from typing import Optional, Dict, Any
import hashlib
import json
import os
import time
from pathlib import Path

from ..services.esp32_chat_server import esp32_chat_server
from ..infrastructure.security.auth import get_current_user

logger = logging.getLogger(__name__)

# Application version - single source of truth
APP_VERSION = "1.3.0"

# Public router - no authentication required
esp32_public = APIRouter(prefix="/api/v1/esp32", tags=["ESP32-Public"])

# Private router - authentication required
esp32_private = APIRouter(
    prefix="/api/v1/esp32",
    tags=["ESP32-Private"],
    dependencies=[Depends(get_current_user)],
)


def _is_valid_esp32_firmware(file_path: str, file_size: int) -> bool:
    """
    Validate if file is a proper ESP32 firmware image.
    
    ESP32 firmware must have:
    - Minimum size (typically 200KB+ for real applications)
    - ESP32 image header format
    
    Args:
        file_path: Path to firmware file
        file_size: Size of the file in bytes
        
    Returns:
        True if valid ESP32 firmware, False otherwise
    """
    # ESP32 firmware minimum size check (200KB minimum for real firmware)
    MIN_FIRMWARE_SIZE = 200 * 1024  # 200KB
    
    if file_size < MIN_FIRMWARE_SIZE:
        logger.warning(f"⚠️ Firmware too small: {file_size} bytes (minimum: {MIN_FIRMWARE_SIZE})")
        return False
    
    # Check ESP32 image header (basic validation)
    try:
        with open(file_path, "rb") as f:
            # Read first 24 bytes (ESP32 image header)
            header = f.read(24)
            if len(header) < 24:
                return False
                
            # ESP32 image magic byte (0xE9 at offset 0)
            if header[0] != 0xE9:
                logger.warning(f"⚠️ Invalid ESP32 magic byte: {hex(header[0])}")
                return False
                
            # Basic segment count check (should be reasonable)
            segment_count = header[1]
            if segment_count == 0 or segment_count > 16:
                logger.warning(f"⚠️ Invalid segment count: {segment_count}")
                return False
                
            logger.info(f"✅ Valid ESP32 firmware detected: {segment_count} segments")
            return True
            
    except Exception as e:
        logger.error(f"❌ Error validating firmware: {e}")
        return False


def _get_firmware_info(firmware_filename: str) -> Dict[str, Any]:
    """
    Get comprehensive firmware information including SHA256, size, and modification time.
    Also validates if the firmware is a proper ESP32 image.
    
    Args:
        firmware_filename: Name of the firmware file
        
    Returns:
        Dictionary with firmware info and validation status
    """
    # Define possible firmware locations
    firmware_paths = [
        f"src/static/firmware/{firmware_filename}",
        f"/app/src/static/firmware/{firmware_filename}",
        f"static/firmware/{firmware_filename}",
        f"/app/static/firmware/{firmware_filename}",
        f"/mnt/c/Users/jaafa/Desktop/ai teddy bear/static/firmware/{firmware_filename}",
        f"/mnt/c/Users/jaafa/Desktop/ai teddy bear/src/static/firmware/{firmware_filename}",
        f"./static/firmware/{firmware_filename}",
        f"./firmware/{firmware_filename}",
    ]

    for firmware_path in firmware_paths:
        if os.path.exists(firmware_path):
            try:
                # Get file stats
                stat_info = os.stat(firmware_path)
                file_size = stat_info.st_size
                last_modified = int(stat_info.st_mtime)
                
                # Calculate SHA256
                sha256_hash = hashlib.sha256()
                with open(firmware_path, "rb") as f:
                    while chunk := f.read(8192):  # 8KB chunks for efficiency
                        sha256_hash.update(chunk)
                hash_result = sha256_hash.hexdigest()
                
                # Validate ESP32 firmware format
                is_valid = _is_valid_esp32_firmware(firmware_path, file_size)
                
                logger.info(
                    f"✅ Found firmware {firmware_filename}: {file_size} bytes, SHA256: {hash_result[:16]}..., Valid: {is_valid}"
                )
                
                return {
                    "exists": True,
                    "path": firmware_path,
                    "size": file_size,
                    "sha256": hash_result,
                    "last_modified": last_modified,
                    "valid": is_valid
                }
            except Exception as e:
                logger.error(f"❌ Error reading firmware {firmware_path}: {e}")
                continue

    # Fallback for missing firmware - deterministic placeholder
    placeholder_data = f"TEDDY_BEAR_FIRMWARE_V{APP_VERSION}_{firmware_filename}".encode()
    placeholder_hash = hashlib.sha256(placeholder_data).hexdigest()
    
    logger.warning(
        f"⚠️ Firmware file {firmware_filename} not found. Using placeholder values."
    )
    
    return {
        "exists": False,
        "path": None,
        "size": 1048576,  # 1MB placeholder
        "sha256": placeholder_hash,
        "last_modified": int(time.time()),
        "valid": False
    }


def _calculate_firmware_sha256(firmware_filename: str) -> str:
    """
    Legacy function for backward compatibility.
    
    DEPRECATED: Use _get_firmware_info() instead.
    """
    firmware_info = _get_firmware_info(firmware_filename)
    return firmware_info["sha256"]


@esp32_private.websocket("/chat")
async def esp32_chat_websocket(
    websocket: WebSocket,
    device_id: str = Query(
        ..., min_length=8, max_length=32, description="Unique ESP32 device identifier"
    ),
    child_id: str = Query(
        ..., min_length=1, max_length=50, description="Child profile identifier"
    ),
    child_name: str = Query(
        ..., min_length=1, max_length=30, description="Child's name"
    ),
    child_age: int = Query(..., ge=3, le=13, description="Child's age (3-13)"),
):
    """
    WebSocket endpoint for ESP32 AI Teddy Bear chat.

    Real-time communication endpoint supporting:
    - Audio streaming (Speech-to-Text)
    - AI response generation
    - Text-to-Speech response streaming
    - Child safety validation
    - Session management

    Query Parameters:
    - device_id: Unique ESP32 device identifier (8-32 alphanumeric chars)
    - child_id: Child profile identifier
    - child_name: Child's name for personalization
    - child_age: Child's age (must be 3-13 for COPPA compliance)

    Message Protocol:
    {
        "type": "audio_chunk|text_message|heartbeat|system_status",
        "data": {...},
        "timestamp": "ISO-8601"
    }
    """
    session_id: Optional[str] = None

    try:
        # Input validation and sanitization
        import re

        # Sanitize device_id
        device_id = re.sub(r"[^a-zA-Z0-9_-]", "", device_id)
        if not device_id or len(device_id) < 8:
            await websocket.close(code=1008, reason="Invalid device ID")
            return

        # Sanitize child_id
        child_id = re.sub(r"[^a-zA-Z0-9_-]", "", child_id)
        if not child_id:
            await websocket.close(code=1008, reason="Invalid child ID")
            return

        # Sanitize child_name
        child_name = re.sub(r"[^a-zA-Z0-9\s]", "", child_name[:30])
        if not child_name:
            child_name = "friend"

        # Validate child_age
        if not isinstance(child_age, int) or not (3 <= child_age <= 13):
            await websocket.close(code=1008, reason="Invalid child age")
            return

        # Connect device and create session
        session_id = await esp32_chat_server.connect_device(
            websocket=websocket,
            device_id=device_id,
            child_id=child_id,
            child_name=child_name,
            child_age=child_age,
        )

        logger.info(
            f"ESP32 WebSocket connected: device_id={device_id}, session_id={session_id}"
        )

        # Message handling loop
        while True:
            try:
                # Receive message from ESP32 with size limit
                raw_message = await websocket.receive_text()

                # Validate message size
                if len(raw_message) > 10000:  # 10KB limit
                    logger.warning(f"Message too large from session {session_id}")
                    await esp32_chat_server._send_error(
                        session_id, "message_too_large", "Message exceeds size limit"
                    )
                    continue

                # Basic message validation
                if not raw_message.strip():
                    continue

                # Handle message through chat server
                await esp32_chat_server.handle_message(session_id, raw_message)

            except WebSocketDisconnect:
                logger.info(f"ESP32 WebSocket disconnected: session_id={session_id}")
                break
            except Exception as e:
                logger.error(f"Message handling error: {e}", exc_info=True)
                # Send error to ESP32 if possible
                try:
                    await esp32_chat_server._send_error(
                        session_id, "processing_error", str(e)
                    )
                except Exception:
                    pass
                break

    except HTTPException:
        # Re-raise FastAPI exceptions (validation errors)
        raise
    except Exception as e:
        logger.error(f"ESP32 WebSocket connection error: {e}", exc_info=True)
        try:
            await websocket.close(code=1011, reason=str(e))
        except Exception:
            pass
    finally:
        # Cleanup session
        if session_id:
            await esp32_chat_server.disconnect_device(session_id, "websocket_closed")


# PUBLIC ROUTES - No authentication required
@esp32_public.get("/config")
async def get_device_config(request: Request, response: Response):
    """
    Get device configuration for ESP32 devices.
    Public endpoint for initial device setup with ETag support.
    """
    config = {
        "host": "ai-tiddy-bear-v.onrender.com",
        "port": 443,
        "ws_path": "/api/v1/esp32/chat",  # Matches WebSocket endpoint in this router
        "tls": True,
        "ntp": ["pool.ntp.org", "time.google.com", "time.cloudflare.com", "time.nist.gov"],
        "features": {
            "ota": True, 
            "strict_tls": True,
            "audio_streaming": True,
            "child_safety": True
        },
        "version": APP_VERSION,
        "timestamp": int(time.time())
    }

    # Generate ETag and set headers BEFORE checking If-None-Match
    etag = '"' + hashlib.sha256(
        json.dumps(config, sort_keys=True).encode()
    ).hexdigest()[:16] + '"'
    
    response.headers["ETag"] = etag
    response.headers["Cache-Control"] = "public, max-age=600, stale-while-revalidate=60"
    
    # Check If-None-Match header for 304 response
    if_none_match = request.headers.get("if-none-match")
    if if_none_match == etag:
        return Response(status_code=304)
    
    # Add improved security headers for successful responses
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none';"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    # Child safety headers
    response.headers["X-Child-Safe"] = "true"
    response.headers["X-COPPA-Compliant"] = "true"
    # Remove deprecated X-XSS-Protection

    return config


@esp32_public.get("/firmware")
async def get_firmware_manifest(request: Request, response: Response):
    """
    Get ESP32 firmware manifest with comprehensive OTA update information.
    Follows Espressif OTA best practices with proper verification fields.
    """
    firmware_filename = "teddy-001.bin"
    firmware_info = _get_firmware_info(firmware_filename)
    
    # Check if firmware is valid before offering it
    if not firmware_info["valid"]:
        logger.error(f"❌ Invalid ESP32 firmware detected: {firmware_filename}")
        raise HTTPException(
            status_code=503, 
            detail="Firmware validation failed - invalid ESP32 image format or insufficient size"
        )
    
    # Build comprehensive firmware manifest
    firmware = {
        "version": APP_VERSION,  # Single source of truth
        "build": int(time.time()),  # Build timestamp
        "mandatory": False,
        "url": f"https://ai-tiddy-bear-v.onrender.com/web/firmware/{firmware_filename}",
        "sha256": firmware_info["sha256"],  # Real file SHA256
        "size": firmware_info["size"],  # Real file size for pre-download verification
        "last_modified": firmware_info["last_modified"],  # File modification timestamp
        "notes": "Production firmware with enhanced child safety, audio processing, and security updates",
        "compatibility": {
            "min_hardware_version": "1.0.0",
            "max_hardware_version": "2.0.0", 
            "required_bootloader": "1.1.0",
            "esp32_variants": ["ESP32", "ESP32-S2", "ESP32-S3"]
        },
        "features": {
            "audio_streaming": True,
            "child_safety": True,
            "ota_updates": True,
            "websocket_support": True,
            "ssl_tls": True
        },
        "file_exists": firmware_info["exists"],
        "validated": firmware_info["valid"]
    }

    # Generate ETag and set headers BEFORE checking If-None-Match
    etag = '"' + hashlib.sha256(
        json.dumps(firmware, sort_keys=True).encode()
    ).hexdigest()[:16] + '"'
    
    response.headers["ETag"] = etag
    response.headers["Cache-Control"] = "public, max-age=300, stale-while-revalidate=60"  # 5 min cache
    
    # Check If-None-Match header for 304 response
    if_none_match = request.headers.get("if-none-match")
    if if_none_match == etag:
        return Response(status_code=304)
    
    # Add improved security headers for successful responses
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none';"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    # Child safety headers
    response.headers["X-Child-Safe"] = "true"
    response.headers["X-COPPA-Compliant"] = "true"
    # Remove deprecated X-XSS-Protection
    
    # Log firmware request
    client_ip = getattr(request.client, "host", "unknown") if request.client else "unknown"
    logger.info(f"✅ ESP32 firmware manifest served to {client_ip} - File exists: {firmware_info['exists']}")

    return firmware


# PRIVATE ROUTES - Authentication required
@esp32_private.get("/metrics")
async def esp32_metrics():
    """ESP32 Chat Server metrics - requires authentication."""
    return esp32_chat_server.get_session_metrics()


# SECURITY FIX: Removed test endpoint - production should not expose test functionality
# Device validation should happen during actual connection establishment only
