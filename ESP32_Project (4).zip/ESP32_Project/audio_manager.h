#pragma once
#include <Arduino.h>
#include <driver/i2s.h>
#include <freertos/FreeRTOS.h>
#include <freertos/stream_buffer.h>
#include <freertos/semphr.h>
#include "production_config.h"

// 🎵 Audio Manager - Production Grade
// ==================================
// مصمم للتعامل مع I2S audio streaming ثنائي الاتجاه
// - Recording: Microphone → ESP32 → Server (16kHz PCM)
// - Playback: Server → ESP32 → Speaker (MP3 → PCM conversion)

enum class AudioState {
    IDLE,
    RECORDING,
    PLAYING,
    ERROR_STATE
};

enum class AudioFormat {
    PCM_16KHZ_MONO,
    MP3_22KHZ_MONO,
    WAV_16KHZ_MONO
};

struct AudioChunk {
    uint8_t* data;
    size_t length;
    uint32_t timestamp;
    uint32_t sequence;
    bool isFinal;
};

struct AudioConfig {
    uint32_t sampleRate = AUDIO_SAMPLE_RATE;
    uint8_t bitsPerSample = AUDIO_BITS_PER_SAMPLE;
    uint8_t channels = AUDIO_CHANNELS;
    AudioFormat format = AudioFormat::PCM_16KHZ_MONO;
    uint8_t volume = AUDIO_VOLUME;
};

class AudioManager {
public:
    AudioManager();
    ~AudioManager();
    
    // 🔧 Initialization
    bool initialize();
    void shutdown();
    bool isInitialized() const { return initialized_; }
    
    // 🎤 Recording Functions
    bool startRecording();
    bool stopRecording();
    bool isRecording() const { return audioState_ == AudioState::RECORDING; }
    
    // 📦 Audio Data Management
    AudioChunk* getNextRecordedChunk(uint32_t timeoutMs = 100);
    void releaseChunk(AudioChunk* chunk);
    size_t getAvailableChunks() const;
    
    // 🔊 Playback Functions
    bool startPlayback();
    bool stopPlayback();
    bool isPlaying() const { return audioState_ == AudioState::PLAYING; }
    
    // 📥 Audio Data Input for Playback
    bool feedAudioData(const uint8_t* data, size_t length, AudioFormat format);
    bool feedMP3Data(const uint8_t* mp3Data, size_t length);
    bool feedPCMData(const uint8_t* pcmData, size_t length);
    
    // ⚙️ Configuration
    void setVolume(uint8_t volume);
    uint8_t getVolume() const { return config_.volume; }
    void setConfig(const AudioConfig& config);
    AudioConfig getConfig() const { return config_; }
    
    // 📊 Statistics and Monitoring
    struct AudioStats {
        uint32_t chunksRecorded = 0;
        uint32_t chunksPlayed = 0;
        uint32_t bytesRecorded = 0;
        uint32_t bytesPlayed = 0;
        uint32_t bufferUnderruns = 0;
        uint32_t bufferOverruns = 0;
        float averageRecordingLevel = 0.0f;
        uint32_t lastActivityMs = 0;
        bool isHealthy = true;
    };
    
    AudioStats getStats() const { return stats_; }
    void resetStats();
    
    // 🎛️ Advanced Controls
    void enableAutoGainControl(bool enable);
    void enableNoiseReduction(bool enable);
    void setSilenceDetectionThreshold(uint16_t threshold);
    bool isSilenceDetected() const;
    
    // 🔊 Audio Level Monitoring
    float getCurrentInputLevel();
    float getCurrentOutputLevel();
    
    // 📞 Event Callbacks
    typedef std::function<void(AudioChunk*)> ChunkReadyCallback;
    typedef std::function<void()> RecordingStartedCallback;
    typedef std::function<void()> RecordingStoppedCallback;
    typedef std::function<void()> PlaybackStartedCallback;
    typedef std::function<void()> PlaybackStoppedCallback;
    typedef std::function<void(const String&)> ErrorCallback;
    
    void onChunkReady(ChunkReadyCallback callback) { onChunkReady_ = callback; }
    void onRecordingStarted(RecordingStartedCallback callback) { onRecordingStarted_ = callback; }
    void onRecordingStopped(RecordingStoppedCallback callback) { onRecordingStopped_ = callback; }
    void onPlaybackStarted(PlaybackStartedCallback callback) { onPlaybackStarted_ = callback; }
    void onPlaybackStopped(PlaybackStoppedCallback callback) { onPlaybackStopped_ = callback; }
    void onError(ErrorCallback callback) { onError_ = callback; }

private:
    bool initialized_ = false;
    AudioState audioState_ = AudioState::IDLE;
    AudioConfig config_;
    AudioStats stats_;
    
    // I2S Configuration
    bool setupI2S();
    void cleanupI2S();
    bool configureI2SForRecording();
    bool configureI2SForPlayback();
    
    // FreeRTOS Resources
    StreamBufferHandle_t recordBuffer_ = nullptr;
    StreamBufferHandle_t playbackBuffer_ = nullptr;
    QueueHandle_t chunkQueue_ = nullptr;
    SemaphoreHandle_t configMutex_ = nullptr;
    TaskHandle_t recordingTask_ = nullptr;
    TaskHandle_t playbackTask_ = nullptr;
    
    // Audio Processing
    bool processRecordedData();
    bool processPlaybackData();
    void applyVolumeControl(int16_t* samples, size_t numSamples);
    void detectSilence(const int16_t* samples, size_t numSamples);
    void calculateAudioLevel(const int16_t* samples, size_t numSamples, bool isInput);
    
    // MP3 Decoding (basic implementation)
    bool decodeMp3ToPcm(const uint8_t* mp3Data, size_t mp3Length, 
                       uint8_t** pcmData, size_t* pcmLength);
    
    // Chunk Management
    AudioChunk* createChunk(size_t length);
    void destroyChunk(AudioChunk* chunk);
    std::vector<AudioChunk*> activeChunks_;
    
    // Silence Detection
    bool silenceDetectionEnabled_ = true;
    uint16_t silenceThreshold_ = AUDIO_SILENCE_THRESHOLD;
    uint32_t silenceStartMs_ = 0;
    bool silenceDetected_ = false;
    
    // Auto Gain Control
    bool agcEnabled_ = false;
    float currentGain_ = 1.0f;
    
    // Noise Reduction
    bool noiseReductionEnabled_ = false;
    
    // Audio Levels
    float currentInputLevel_ = 0.0f;
    float currentOutputLevel_ = 0.0f;
    
    // Error handling
    uint8_t consecutiveErrors_ = 0;
    uint32_t lastErrorMs_ = 0;
    
    // Event Callbacks
    ChunkReadyCallback onChunkReady_;
    RecordingStartedCallback onRecordingStarted_;
    RecordingStoppedCallback onRecordingStopped_;
    PlaybackStartedCallback onPlaybackStarted_;
    PlaybackStoppedCallback onPlaybackStopped_;
    ErrorCallback onError_;
    
    // Static task functions for FreeRTOS
    static void recordingTaskFunction(void* parameter);
    static void playbackTaskFunction(void* parameter);
    
    // Utility functions
    void logError(const String& error);
    void updateStats();
    bool validateAudioData(const uint8_t* data, size_t length);
};

// Global instance
extern AudioManager audioManager;