#pragma once
#include <Arduino.h>

// 🧸 AI Teddy Bear ESP32 - Production Configuration
// ================================================
// مخصص للتطابق مع سيرفر: ai-tiddy-bear-v-xuqy.onrender.com
// WebSocket: /api/v1/esp32/connect

// 🌐 Server Configuration - مطابق للسيرفر الفعلي
static constexpr const char* SERVER_HOST = "ai-tiddy-bear-v-xuqy.onrender.com";
static constexpr uint16_t SERVER_PORT = 443;
static constexpr const char* WS_ENDPOINT = "/api/v1/esp32/connect";
static constexpr const char* WS_PROTOCOL = "teddy-bear-v1";

// 🔐 Security Configuration
static constexpr uint32_t JWT_REFRESH_BEFORE_EXPIRY_MS = 5 * 60 * 1000; // 5 minutes before expiry
static constexpr uint32_t HMAC_MAX_CLOCK_SKEW_MS = 30 * 1000; // 30 seconds
static constexpr const char* TLS_SNI_NAME = "ai-tiddy-bear-v-xuqy.onrender.com";

// 📡 Network Configuration
static constexpr uint32_t WIFI_CONNECT_TIMEOUT_MS = 30000;
static constexpr uint32_t WIFI_BACKOFF_BASE_MS = 2000;
static constexpr uint32_t WIFI_BACKOFF_MAX_MS = 30000;
static constexpr uint8_t WIFI_MAX_RETRIES = 15;
static constexpr uint32_t NETWORK_CHECK_INTERVAL_MS = 5000;

// 🔌 WebSocket Configuration
static constexpr uint32_t WS_CONNECT_TIMEOUT_MS = 15000;
static constexpr uint32_t WS_PING_INTERVAL_MS = 15000; // Heartbeat every 15 seconds
static constexpr uint32_t WS_PONG_TIMEOUT_MS = 8000;
static constexpr uint32_t WS_RECONNECT_MIN_MS = 3000;
static constexpr uint32_t WS_RECONNECT_MAX_MS = 30000;
static constexpr uint8_t WS_MAX_RECONNECT_ATTEMPTS = 10;

// 🎵 Audio Configuration - مطابق لمتطلبات Whisper
static constexpr uint32_t AUDIO_SAMPLE_RATE = 16000; // 16kHz for Whisper compatibility
static constexpr uint8_t AUDIO_BITS_PER_SAMPLE = 16; // 16-bit
static constexpr uint8_t AUDIO_CHANNELS = 1; // Mono
static constexpr uint16_t AUDIO_CHUNK_SIZE = 4096; // 4KB chunks match server expectation
static constexpr uint32_t AUDIO_BUFFER_SIZE = 128 * 1024; // 128KB total buffer
static constexpr uint32_t AUDIO_MAX_RECORDING_MS = 10000; // 10 seconds max recording
static constexpr uint32_t AUDIO_SILENCE_THRESHOLD = 500; // Auto-stop after 500ms silence

// 🎤 I2S Configuration
static constexpr uint8_t I2S_DMA_BUF_COUNT = 8;
static constexpr uint16_t I2S_DMA_BUF_LEN = 1024;
static constexpr bool I2S_USE_APLL = false;
static constexpr uint32_t I2S_FIXED_MCLK = 0;

// 🔊 Audio Playback Configuration
static constexpr uint32_t PLAYBACK_BUFFER_SIZE = 64 * 1024; // 64KB for MP3 playback
static constexpr uint16_t PLAYBACK_CHUNK_SIZE = 2048;
static constexpr uint8_t AUDIO_VOLUME = 80; // 0-100 volume level

// 🎛️ Task Configuration
static constexpr uint32_t TASK_STACK_WIFI_MANAGER = 4096;
static constexpr uint32_t TASK_STACK_WEBSOCKET = 8192;
static constexpr uint32_t TASK_STACK_AUDIO_CAPTURE = 6144;
static constexpr uint32_t TASK_STACK_AUDIO_PLAYBACK = 6144;
static constexpr uint32_t TASK_STACK_SYSTEM_MONITOR = 3072;

// Task priorities
static constexpr UBaseType_t TASK_PRIORITY_AUDIO_HIGH = 5;
static constexpr UBaseType_t TASK_PRIORITY_WEBSOCKET = 4;
static constexpr UBaseType_t TASK_PRIORITY_WIFI = 3;
static constexpr UBaseType_t TASK_PRIORITY_MONITOR = 2;

// Core assignment
static constexpr BaseType_t TASK_CORE_AUDIO = 0;
static constexpr BaseType_t TASK_CORE_NETWORK = 1;

// 📊 Monitoring Configuration
static constexpr uint32_t HEALTH_REPORT_INTERVAL_MS = 30000; // 30 seconds
static constexpr uint32_t STATS_REPORT_INTERVAL_MS = 60000; // 1 minute
static constexpr uint32_t WDT_TIMEOUT_SECONDS = 15;
static constexpr uint32_t MEMORY_CHECK_INTERVAL_MS = 10000;

// 🚨 Error Handling
static constexpr uint8_t MAX_CONSECUTIVE_ERRORS = 5;
static constexpr uint32_t ERROR_RECOVERY_DELAY_MS = 5000;
static constexpr uint32_t CRITICAL_ERROR_RESTART_MS = 300000; // 5 minutes

// 🧸 Child Safety & COPPA Compliance
static constexpr uint8_t MIN_CHILD_AGE = 3;
static constexpr uint8_t MAX_CHILD_AGE = 13;
static constexpr uint32_t SESSION_MAX_DURATION_MS = 30 * 60 * 1000; // 30 minutes max
static constexpr uint32_t INTERACTION_TIMEOUT_MS = 5 * 60 * 1000; // 5 minutes inactivity

// 🔋 Power Management
static constexpr uint32_t SLEEP_MODE_TIMEOUT_MS = 10 * 60 * 1000; // 10 minutes to sleep
static constexpr bool ENABLE_LIGHT_SLEEP = true;
static constexpr uint32_t CPU_FREQ_MHZ = 240; // Full speed for audio processing

// 📝 Logging Configuration
#define LOG_LEVEL_PRODUCTION 2 // 0=None, 1=Error, 2=Warning, 3=Info, 4=Debug
#define MAX_LOG_MESSAGE_SIZE 256
#define LOG_BUFFER_SIZE 2048

// 🔧 Hardware Configuration (تحديث حسب لوحتك)
namespace HardwarePins {
    // I2S Audio Pins
    static constexpr int I2S_BCLK = 26;  // Bit Clock
    static constexpr int I2S_LRC = 25;   // Left/Right Clock (Word Select)
    static constexpr int I2S_DIN = 33;   // Data Input (Microphone)
    static constexpr int I2S_DOUT = 22;  // Data Output (Speaker)
    
    // Control Pins
    static constexpr int BUTTON_MAIN = 0;    // Main interaction button (BOOT button)
    static constexpr int LED_STATUS = 2;     // Status LED (built-in)
    
    // Audio Control
    static constexpr int AUDIO_AMP_ENABLE = 21; // Audio amplifier enable
    static constexpr int AUDIO_MUTE = 19;       // Audio mute control
    
    // Power Management
    static constexpr int POWER_HOLD = 18;       // Power hold pin
    static constexpr int BATTERY_ADC = 35;      // Battery voltage monitoring
}

// 🎯 Device Identification
#ifndef DEVICE_MODEL
#define DEVICE_MODEL "AI-TeddyBear-ESP32"
#endif

#ifndef FIRMWARE_VERSION
#define FIRMWARE_VERSION "1.0.0-production"
#endif

// 📦 Memory Management
static constexpr size_t MIN_FREE_HEAP = 50 * 1024; // 50KB minimum
static constexpr size_t CRITICAL_HEAP_THRESHOLD = 20 * 1024; // 20KB critical
static constexpr bool USE_PSRAM = true; // Enable PSRAM if available

// 🌡️ Temperature Monitoring
static constexpr float MAX_OPERATING_TEMP = 70.0f; // Celsius
static constexpr float TEMP_WARNING_THRESHOLD = 60.0f;

// 🔄 OTA Update Configuration
static constexpr uint32_t OTA_CHECK_INTERVAL_MS = 24 * 60 * 60 * 1000; // Daily
static constexpr uint16_t OTA_HTTP_PORT = 80;
static constexpr uint32_t OTA_TIMEOUT_MS = 30000;

// Debug and Development
#ifdef DEBUG_BUILD
#undef LOG_LEVEL_PRODUCTION
#define LOG_LEVEL_PRODUCTION 4
static constexpr bool ENABLE_SERIAL_DEBUG = true;
static constexpr uint32_t DEBUG_REPORT_INTERVAL_MS = 5000;
#else
static constexpr bool ENABLE_SERIAL_DEBUG = false;
static constexpr uint32_t DEBUG_REPORT_INTERVAL_MS = 0;
#endif

// Validation macros
static_assert(AUDIO_SAMPLE_RATE == 16000, "Server expects 16kHz audio");
static_assert(AUDIO_CHANNELS == 1, "Server expects mono audio");
static_assert(MIN_CHILD_AGE >= 3 && MAX_CHILD_AGE <= 13, "COPPA compliance age range");
static_assert(WS_PING_INTERVAL_MS <= 30000, "Ping interval too long for production");