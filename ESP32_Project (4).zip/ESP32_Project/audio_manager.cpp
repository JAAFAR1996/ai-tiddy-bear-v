#include "audio_manager.h"
#include <cmath>
#include <algorithm>

AudioManager audioManager;

AudioManager::AudioManager() {
    // تهيئة callbacks فارغة
    onChunkReady_ = [](AudioChunk*) {};
    onRecordingStarted_ = []() {};
    onRecordingStopped_ = []() {};
    onPlaybackStarted_ = []() {};
    onPlaybackStopped_ = []() {};
    onError_ = [](const String&) {};
}

AudioManager::~AudioManager() {
    shutdown();
}

bool AudioManager::initialize() {
    if (initialized_) {
        return true;
    }
    
    Serial.println("🎵 Initializing Audio Manager...");
    
    // إنشاء mutex للحماية من التداخل
    configMutex_ = xSemaphoreCreateMutex();
    if (!configMutex_) {
        logError("Failed to create config mutex");
        return false;
    }
    
    // إنشاء stream buffers للصوت
    recordBuffer_ = xStreamBufferCreate(AUDIO_BUFFER_SIZE, AUDIO_CHUNK_SIZE);
    playbackBuffer_ = xStreamBufferCreate(PLAYBACK_BUFFER_SIZE, PLAYBACK_CHUNK_SIZE);
    
    if (!recordBuffer_ || !playbackBuffer_) {
        logError("Failed to create audio buffers");
        return false;
    }
    
    // إنشاء queue للـ chunks
    chunkQueue_ = xQueueCreate(16, sizeof(AudioChunk*));
    if (!chunkQueue_) {
        logError("Failed to create chunk queue");
        return false;
    }
    
    // تكوين I2S
    if (!setupI2S()) {
        logError("Failed to setup I2S");
        return false;
    }
    
    // بدء المهام
    BaseType_t result = xTaskCreatePinnedToCore(
        recordingTaskFunction,
        "AudioRecord",
        TASK_STACK_AUDIO_CAPTURE,
        this,
        TASK_PRIORITY_AUDIO_HIGH,
        &recordingTask_,
        TASK_CORE_AUDIO
    );
    
    if (result != pdPASS) {
        logError("Failed to create recording task");
        return false;
    }
    
    result = xTaskCreatePinnedToCore(
        playbackTaskFunction,
        "AudioPlayback", 
        TASK_STACK_AUDIO_PLAYBACK,
        this,
        TASK_PRIORITY_AUDIO_HIGH,
        &playbackTask_,
        TASK_CORE_AUDIO
    );
    
    if (result != pdPASS) {
        logError("Failed to create playback task");
        return false;
    }
    
    initialized_ = true;
    Serial.println("✅ Audio Manager initialized successfully");
    return true;
}

bool AudioManager::setupI2S() {
    // تكوين I2S للتسجيل والتشغيل
    i2s_config_t i2s_config = {
        .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX | I2S_MODE_TX),
        .sample_rate = config_.sampleRate,
        .bits_per_sample = (i2s_bits_per_sample_t)config_.bitsPerSample,
        .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT, // Mono
        .communication_format = I2S_COMM_FORMAT_STAND_I2S,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
        .dma_buf_count = I2S_DMA_BUF_COUNT,
        .dma_buf_len = I2S_DMA_BUF_LEN,
        .use_apll = I2S_USE_APLL,
        .tx_desc_auto_clear = true,
        .fixed_mclk = I2S_FIXED_MCLK
    };
    
    // تكوين الدبابيس
    i2s_pin_config_t pin_config = {
        .mck_io_num = -1, // Master clock (غير مستخدم)
        .bck_io_num = HardwarePins::I2S_BCLK,
        .ws_io_num = HardwarePins::I2S_LRC,
        .data_out_num = HardwarePins::I2S_DOUT,
        .data_in_num = HardwarePins::I2S_DIN
    };
    
    // تثبيت I2S driver
    esp_err_t err = i2s_driver_install(I2S_NUM_0, &i2s_config, 0, nullptr);
    if (err != ESP_OK) {
        Serial.printf("❌ Failed to install I2S driver: %s\n", esp_err_to_name(err));
        return false;
    }
    
    err = i2s_set_pin(I2S_NUM_0, &pin_config);
    if (err != ESP_OK) {
        Serial.printf("❌ Failed to set I2S pins: %s\n", esp_err_to_name(err));
        i2s_driver_uninstall(I2S_NUM_0);
        return false;
    }
    
    // مسح DMA buffers
    i2s_zero_dma_buffer(I2S_NUM_0);
    
    Serial.printf("✅ I2S configured: %dHz, %d-bit, %s\n", 
                  config_.sampleRate, config_.bitsPerSample, 
                  config_.channels == 1 ? "Mono" : "Stereo");
    
    return true;
}

bool AudioManager::startRecording() {
    if (!initialized_ || audioState_ == AudioState::RECORDING) {
        return false;
    }
    
    Serial.println("🎤 Starting audio recording...");
    
    // مسح المخزن المؤقت
    xStreamBufferReset(recordBuffer_);
    resetStats();
    
    audioState_ = AudioState::RECORDING;
    stats_.lastActivityMs = millis();
    
    onRecordingStarted_();
    Serial.println("✅ Recording started");
    
    return true;
}

bool AudioManager::stopRecording() {
    if (audioState_ != AudioState::RECORDING) {
        return false;
    }
    
    Serial.println("⏹️ Stopping audio recording...");
    
    audioState_ = AudioState::IDLE;
    onRecordingStopped_();
    
    Serial.println("✅ Recording stopped");
    return true;
}

bool AudioManager::startPlayback() {
    if (!initialized_) {
        return false;
    }
    
    Serial.println("🔊 Starting audio playback...");
    
    if (audioState_ == AudioState::RECORDING) {
        stopRecording();
        vTaskDelay(pdMS_TO_TICKS(100)); // انتظار قصير
    }
    
    audioState_ = AudioState::PLAYING;
    onPlaybackStarted_();
    
    Serial.println("✅ Playback started");
    return true;
}

bool AudioManager::stopPlayback() {
    if (audioState_ != AudioState::PLAYING) {
        return false;
    }
    
    Serial.println("⏹️ Stopping audio playback...");
    
    audioState_ = AudioState::IDLE;
    onPlaybackStopped_();
    
    Serial.println("✅ Playback stopped");
    return true;
}

AudioChunk* AudioManager::getNextRecordedChunk(uint32_t timeoutMs) {
    AudioChunk* chunk = nullptr;
    
    BaseType_t result = xQueueReceive(chunkQueue_, &chunk, 
                                     pdMS_TO_TICKS(timeoutMs));
    
    if (result == pdTRUE && chunk != nullptr) {
        return chunk;
    }
    
    return nullptr;
}

void AudioManager::releaseChunk(AudioChunk* chunk) {
    if (chunk) {
        destroyChunk(chunk);
    }
}

bool AudioManager::feedMP3Data(const uint8_t* mp3Data, size_t length) {
    if (!mp3Data || length == 0) {
        return false;
    }
    
    // فك تشفير MP3 إلى PCM (تطبيق مبسط)
    uint8_t* pcmData = nullptr;
    size_t pcmLength = 0;
    
    if (decodeMp3ToPcm(mp3Data, length, &pcmData, &pcmLength)) {
        bool success = feedPCMData(pcmData, pcmLength);
        free(pcmData); // تحرير الذاكرة المؤقتة
        return success;
    }
    
    return false;
}

bool AudioManager::feedPCMData(const uint8_t* pcmData, size_t length) {
    if (!pcmData || length == 0 || !playbackBuffer_) {
        return false;
    }
    
    // تطبيق التحكم في مستوى الصوت
    int16_t* samples = (int16_t*)pcmData;
    size_t numSamples = length / 2; // 16-bit samples
    
    // إنشاء نسخة للمعالجة
    int16_t* processedSamples = (int16_t*)malloc(length);
    if (!processedSamples) {
        return false;
    }
    
    memcpy(processedSamples, samples, length);
    applyVolumeControl(processedSamples, numSamples);
    
    // إرسال البيانات إلى playback buffer
    size_t sent = xStreamBufferSend(playbackBuffer_, processedSamples, length, 
                                   pdMS_TO_TICKS(100));
    
    free(processedSamples);
    
    if (sent == length) {
        stats_.bytesPlayed += length;
        calculateAudioLevel(samples, numSamples, false);
        return true;
    }
    
    stats_.bufferOverruns++;
    return false;
}

void AudioManager::setVolume(uint8_t volume) {
    if (xSemaphoreTake(configMutex_, pdMS_TO_TICKS(100)) == pdTRUE) {
        config_.volume = std::min<uint8_t>(volume, 100);
        Serial.printf("🔊 Volume set to: %d%%\n", config_.volume);
        xSemaphoreGive(configMutex_);
    }
}

void AudioManager::applyVolumeControl(int16_t* samples, size_t numSamples) {
    if (config_.volume == 100) {
        return; // لا حاجة للمعالجة
    }
    
    float volumeMultiplier = config_.volume / 100.0f;
    
    for (size_t i = 0; i < numSamples; i++) {
        float sample = samples[i] * volumeMultiplier;
        samples[i] = (int16_t)std::clamp(sample, -32768.0f, 32767.0f);
    }
}

void AudioManager::calculateAudioLevel(const int16_t* samples, size_t numSamples, bool isInput) {
    if (!samples || numSamples == 0) return;
    
    // حساب RMS level
    float sum = 0.0f;
    for (size_t i = 0; i < numSamples; i++) {
        float sample = samples[i] / 32768.0f; // Normalize to [-1, 1]
        sum += sample * sample;
    }
    
    float rms = sqrt(sum / numSamples);
    float level = 20.0f * log10f(rms + 1e-10f); // دB
    
    if (isInput) {
        currentInputLevel_ = level;
        stats_.averageRecordingLevel = (stats_.averageRecordingLevel * 0.9f) + (level * 0.1f);
    } else {
        currentOutputLevel_ = level;
    }
}

void AudioManager::detectSilence(const int16_t* samples, size_t numSamples) {
    if (!silenceDetectionEnabled_) return;
    
    // حساب متوسط الطاقة
    uint32_t energy = 0;
    for (size_t i = 0; i < numSamples; i++) {
        energy += abs(samples[i]);
    }
    energy /= numSamples;
    
    bool currentSilence = energy < silenceThreshold_;
    
    if (currentSilence && !silenceDetected_) {
        silenceStartMs_ = millis();
        silenceDetected_ = true;
    } else if (!currentSilence) {
        silenceDetected_ = false;
    }
}

bool AudioManager::decodeMp3ToPcm(const uint8_t* mp3Data, size_t mp3Length,
                                 uint8_t** pcmData, size_t* pcmLength) {
    // تطبيق مبسط - في الواقع تحتاج مكتبة MP3 decoder
    // هنا نعتبر البيانات PCM مباشرة للاختبار
    
    *pcmLength = mp3Length; // تقدير مبسط
    *pcmData = (uint8_t*)malloc(*pcmLength);
    
    if (!*pcmData) {
        return false;
    }
    
    // محاكاة فك التشفير - في التطبيق الحقيقي استخدم مكتبة مثل libmad أو ESP32-Audio
    memcpy(*pcmData, mp3Data, *pcmLength);
    
    return true;
}

AudioChunk* AudioManager::createChunk(size_t length) {
    AudioChunk* chunk = new AudioChunk();
    chunk->data = (uint8_t*)malloc(length);
    chunk->length = length;
    chunk->timestamp = millis();
    chunk->sequence = stats_.chunksRecorded;
    chunk->isFinal = false;
    
    if (!chunk->data) {
        delete chunk;
        return nullptr;
    }
    
    activeChunks_.push_back(chunk);
    return chunk;
}

void AudioManager::destroyChunk(AudioChunk* chunk) {
    if (!chunk) return;
    
    // إزالة من القائمة النشطة
    auto it = std::find(activeChunks_.begin(), activeChunks_.end(), chunk);
    if (it != activeChunks_.end()) {
        activeChunks_.erase(it);
    }
    
    if (chunk->data) {
        free(chunk->data);
    }
    delete chunk;
}

// مهمة التسجيل
void AudioManager::recordingTaskFunction(void* parameter) {
    AudioManager* manager = static_cast<AudioManager*>(parameter);
    
    uint8_t* buffer = (uint8_t*)malloc(AUDIO_CHUNK_SIZE);
    if (!buffer) {
        manager->logError("Failed to allocate recording buffer");
        vTaskDelete(nullptr);
        return;
    }
    
    Serial.println("🎤 Recording task started");
    
    while (true) {
        if (manager->audioState_ == AudioState::RECORDING) {
            size_t bytesRead = 0;
            
            // قراءة من I2S
            esp_err_t err = i2s_read(I2S_NUM_0, buffer, AUDIO_CHUNK_SIZE, 
                                   &bytesRead, pdMS_TO_TICKS(100));
            
            if (err == ESP_OK && bytesRead > 0) {
                // إنشاء chunk جديد
                AudioChunk* chunk = manager->createChunk(bytesRead);
                if (chunk) {
                    memcpy(chunk->data, buffer, bytesRead);
                    
                    // كشف الصمت
                    manager->detectSilence((int16_t*)chunk->data, bytesRead / 2);
                    
                    // حساب مستوى الصوت
                    manager->calculateAudioLevel((int16_t*)chunk->data, bytesRead / 2, true);
                    
                    // إرسال الـ chunk
                    if (xQueueSend(manager->chunkQueue_, &chunk, 0) != pdTRUE) {
                        manager->destroyChunk(chunk);
                        manager->stats_.bufferOverruns++;
                    } else {
                        manager->stats_.chunksRecorded++;
                        manager->stats_.bytesRecorded += bytesRead;
                        manager->onChunkReady_(chunk);
                    }
                }
                
                manager->stats_.lastActivityMs = millis();
                manager->updateStats();
            }
        } else {
            vTaskDelay(pdMS_TO_TICKS(10)); // انتظار عندما لا نسجل
        }
    }
    
    free(buffer);
    vTaskDelete(nullptr);
}

// مهمة التشغيل
void AudioManager::playbackTaskFunction(void* parameter) {
    AudioManager* manager = static_cast<AudioManager*>(parameter);
    
    uint8_t* buffer = (uint8_t*)malloc(PLAYBACK_CHUNK_SIZE);
    if (!buffer) {
        manager->logError("Failed to allocate playback buffer");
        vTaskDelete(nullptr);
        return;
    }
    
    Serial.println("🔊 Playback task started");
    
    while (true) {
        if (manager->audioState_ == AudioState::PLAYING) {
            size_t received = xStreamBufferReceive(manager->playbackBuffer_, 
                                                  buffer, PLAYBACK_CHUNK_SIZE, 
                                                  pdMS_TO_TICKS(100));
            
            if (received > 0) {
                size_t bytesWritten = 0;
                esp_err_t err = i2s_write(I2S_NUM_0, buffer, received, 
                                        &bytesWritten, pdMS_TO_TICKS(100));
                
                if (err == ESP_OK) {
                    manager->stats_.chunksPlayed++;
                } else {
                    manager->stats_.bufferUnderruns++;
                }
            } else {
                // لا توجد بيانات للتشغيل - انتهى الصوت
                manager->stopPlayback();
            }
        } else {
            vTaskDelay(pdMS_TO_TICKS(10));
        }
    }
    
    free(buffer);
    vTaskDelete(nullptr);
}

void AudioManager::shutdown() {
    if (!initialized_) return;
    
    Serial.println("🔇 Shutting down Audio Manager...");
    
    // إيقاف المهام
    if (recordingTask_) {
        vTaskDelete(recordingTask_);
        recordingTask_ = nullptr;
    }
    
    if (playbackTask_) {
        vTaskDelete(playbackTask_);
        playbackTask_ = nullptr;
    }
    
    // تنظيف I2S
    i2s_driver_uninstall(I2S_NUM_0);
    
    // تنظيف FreeRTOS resources
    if (recordBuffer_) {
        vStreamBufferDelete(recordBuffer_);
        recordBuffer_ = nullptr;
    }
    
    if (playbackBuffer_) {
        vStreamBufferDelete(playbackBuffer_);
        playbackBuffer_ = nullptr;
    }
    
    if (chunkQueue_) {
        vQueueDelete(chunkQueue_);
        chunkQueue_ = nullptr;
    }
    
    if (configMutex_) {
        vSemaphoreDelete(configMutex_);
        configMutex_ = nullptr;
    }
    
    // تنظيف الـ chunks النشطة
    for (auto chunk : activeChunks_) {
        destroyChunk(chunk);
    }
    activeChunks_.clear();
    
    initialized_ = false;
    audioState_ = AudioState::IDLE;
    
    Serial.println("✅ Audio Manager shutdown complete");
}

void AudioManager::logError(const String& error) {
    Serial.printf("❌ AudioManager Error: %s\n", error.c_str());
    consecutiveErrors_++;
    lastErrorMs_ = millis();
    
    if (consecutiveErrors_ >= MAX_CONSECUTIVE_ERRORS) {
        stats_.isHealthy = false;
    }
    
    onError_(error);
}

void AudioManager::updateStats() {
    stats_.isHealthy = (consecutiveErrors_ < MAX_CONSECUTIVE_ERRORS);
    
    // إعادة تعيين العدادات إذا لم تحدث أخطاء لفترة
    if (millis() - lastErrorMs_ > 60000) { // دقيقة واحدة
        consecutiveErrors_ = 0;
        stats_.isHealthy = true;
    }
}

void AudioManager::resetStats() {
    stats_ = AudioStats(); // إعادة تعيين جميع القيم
    consecutiveErrors_ = 0;
    stats_.isHealthy = true;
}

// Getters للمراقبة
size_t AudioManager::getAvailableChunks() const {
    return uxQueueMessagesWaiting(chunkQueue_);
}

float AudioManager::getCurrentInputLevel() {
    return currentInputLevel_;
}

float AudioManager::getCurrentOutputLevel() {
    return currentOutputLevel_;
}

bool AudioManager::isSilenceDetected() const {
    if (!silenceDetected_) return false;
    
    // تأكيد الصمت لمدة محددة
    return (millis() - silenceStartMs_) > 1000; // ثانية واحدة من الصمت
}