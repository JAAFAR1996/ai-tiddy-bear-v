#pragma once
#include <Arduino.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>
#include "production_config.h"

// 🔌 WebSocket Client للاتصال بـ AI Teddy Bear Server
// ===================================================
// يتطابق تماماً مع بروتوكول السيرفر المُحلل من الكود

enum class WebSocketState {
    DISCONNECTED,
    CONNECTING, 
    AUTHENTICATING,
    CONNECTED,
    ERROR_STATE
};

enum class AudioSessionState {
    IDLE,
    STARTING,
    STREAMING,
    PROCESSING,
    RECEIVING_RESPONSE
};

// رسائل WebSocket حسب بروتوكول السيرفر الفعلي
struct ServerMessage {
    String type;
    JsonDocument data;
};

struct AudioChunk {
    String type = "audio_chunk";
    String audio_data; // base64 encoded
    String chunk_id;
    String audio_session_id; 
    bool is_final = false;
    uint32_t sequence = 0;
    uint32_t timestamp;
};

struct AudioResponse {
    String type = "audio_response";
    String audio_data; // base64 MP3 data
    String text;
    String format = "mp3";
    int sample_rate = 22050;
    uint32_t timestamp;
};

class WebSocketClient {
public:
    WebSocketClient();
    ~WebSocketClient();
    
    // 🔗 Connection Management
    bool begin(const String& deviceId, const String& childId, 
               const String& childName, int childAge, const String& jwtToken);
    void loop();
    void disconnect();
    bool isConnected() const;
    WebSocketState getState() const { return state_; }
    
    // 🎵 Audio Streaming (مطابق لبروتوكول السيرفر)
    bool startAudioSession();
    bool sendAudioChunk(const uint8_t* audioData, size_t length, 
                       bool isFinal = false, uint32_t sequence = 0);
    bool endAudioSession();
    
    // 💬 Text Communication
    bool sendTextMessage(const String& message);
    bool sendHeartbeat();
    bool sendSystemStatus(const JsonDocument& status);
    
    // 📊 Monitoring
    struct ConnectionStats {
        uint32_t messagesReceived = 0;
        uint32_t messagesSent = 0;
        uint32_t audioChunksSent = 0;
        uint32_t audioResponsesReceived = 0;
        uint32_t reconnectCount = 0;
        uint32_t lastPingMs = 0;
        uint32_t lastPongMs = 0;
        uint32_t connectionUptimeMs = 0;
        bool isHealthy = false;
    };
    
    ConnectionStats getStats() const { return stats_; }
    
    // 📞 Event Callbacks
    typedef std::function<void(const ServerMessage&)> MessageCallback;
    typedef std::function<void(const AudioResponse&)> AudioResponseCallback;
    typedef std::function<void(const String& text)> TextResponseCallback;
    typedef std::function<void(const String& errorCode, const String& message)> ErrorCallback;
    typedef std::function<void()> ConnectionCallback;
    
    void onMessage(MessageCallback callback) { onMessage_ = callback; }
    void onAudioResponse(AudioResponseCallback callback) { onAudioResponse_ = callback; }
    void onTextResponse(TextResponseCallback callback) { onTextResponse_ = callback; }
    void onError(ErrorCallback callback) { onError_ = callback; }
    void onConnected(ConnectionCallback callback) { onConnected_ = callback; }
    void onDisconnected(ConnectionCallback callback) { onDisconnected_ = callback; }

private:
    WebSocketsClient webSocket_;
    WebSocketState state_ = WebSocketState::DISCONNECTED;
    AudioSessionState audioState_ = AudioSessionState::IDLE;
    
    // Connection parameters
    String deviceId_;
    String childId_;
    String childName_;
    int childAge_;
    String jwtToken_;
    String currentAudioSessionId_;
    
    // Statistics and monitoring
    ConnectionStats stats_;
    uint32_t connectionStartMs_ = 0;
    uint32_t lastHeartbeatMs_ = 0;
    uint32_t reconnectAttempts_ = 0;
    uint32_t lastReconnectMs_ = 0;
    
    // Message handling
    void webSocketEvent(WStype_t type, uint8_t * payload, size_t length);
    void handleTextMessage(const String& message);
    void handleSystemMessage(const JsonDocument& data);
    void handleAudioResponse(const JsonDocument& doc);
    void handleTextResponse(const JsonDocument& doc);
    void handleErrorMessage(const JsonDocument& doc);
    void handleHeartbeatResponse(const JsonDocument& doc);
    
    // Utility functions
    String generateUUID();
    String encodeBase64(const uint8_t* data, size_t length);
    bool sendJsonMessage(const JsonDocument& doc);
    void updateConnectionStats();
    void scheduleReconnect();
    
    // Security
    bool validateServerMessage(const JsonDocument& doc);
    void logSecurityEvent(const String& event, const String& details);
    
    // Event callbacks
    MessageCallback onMessage_;
    AudioResponseCallback onAudioResponse_;
    TextResponseCallback onTextResponse_;
    ErrorCallback onError_;
    ConnectionCallback onConnected_;
    ConnectionCallback onDisconnected_;
    
    // Internal state management
    bool shouldReconnect_ = true;
    uint32_t nextReconnectMs_ = 0;
    uint8_t consecutiveErrors_ = 0;
};

// Global instance for task access
extern WebSocketClient webSocketClient;