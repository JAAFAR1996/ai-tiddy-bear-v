#include "websocket_client.h"
#include "secrets_template.h" // في الإنتاج: #include "secrets.h"
#include <base64.h>
#include <WiFi.h>

WebSocketClient webSocketClient;

WebSocketClient::WebSocketClient() {
    // تهيئة callbacks فارغة لتجنب null pointer
    onMessage_ = [](const ServerMessage&) {};
    onAudioResponse_ = [](const AudioResponse&) {};  
    onTextResponse_ = [](const String&) {};
    onError_ = [](const String&, const String&) {};
    onConnected_ = []() {};
    onDisconnected_ = []() {};
}

WebSocketClient::~WebSocketClient() {
    disconnect();
}

bool WebSocketClient::begin(const String& deviceId, const String& childId,
                           const String& childName, int childAge, const String& jwtToken) {
    deviceId_ = deviceId;
    childId_ = childId;
    childName_ = childName;
    childAge_ = childAge;
    jwtToken_ = jwtToken;
    
    // تحقق من صحة المعاملات (COPPA compliance)
    if (childAge < MIN_CHILD_AGE || childAge > MAX_CHILD_AGE) {
        Serial.printf("❌ Invalid child age: %d (must be %d-%d)\n", 
                     childAge, MIN_CHILD_AGE, MAX_CHILD_AGE);
        return false;
    }
    
    // بناء URL مع query parameters حسب متطلبات السيرفر
    String wsUrl = String(WS_ENDPOINT) + "?";
    wsUrl += "device_id=" + deviceId;
    wsUrl += "&child_id=" + childId;
    wsUrl += "&child_name=" + childName;  
    wsUrl += "&child_age=" + String(childAge);
    
    Serial.printf("🔗 Connecting to: wss://%s:%d%s\n", 
                  SERVER_HOST, SERVER_PORT, wsUrl.c_str());
    
    // تكوين WebSocket مع SSL
    webSocket_.beginSSL(SERVER_HOST, SERVER_PORT, wsUrl);
    webSocket_.onEvent([this](WStype_t type, uint8_t * payload, size_t length) {
        webSocketEvent(type, payload, length);
    });
    
    // تكوين heartbeat حسب إعدادات السيرفر  
    webSocket_.enableHeartbeat(WS_PING_INTERVAL_MS, WS_PONG_TIMEOUT_MS, 3);
    webSocket_.setReconnectInterval(WS_RECONNECT_MIN_MS);
    
    // إضافة headers للمصادقة
    String headers = "Authorization: Bearer " + jwtToken + "\r\n";
    headers += "X-Device-Model: " + String(DEVICE_MODEL) + "\r\n";
    headers += "X-Firmware-Version: " + String(FIRMWARE_VERSION) + "\r\n";
    webSocket_.setExtraHeaders(headers.c_str());
    
    state_ = WebSocketState::CONNECTING;
    connectionStartMs_ = millis();
    
    return true;
}

void WebSocketClient::webSocketEvent(WStype_t type, uint8_t * payload, size_t length) {
    switch(type) {
        case WStype_DISCONNECTED:
            Serial.println("❌ WebSocket Disconnected");
            state_ = WebSocketState::DISCONNECTED;
            audioState_ = AudioSessionState::IDLE;
            onDisconnected_();
            scheduleReconnect();
            break;
            
        case WStype_CONNECTED:
            Serial.printf("✅ WebSocket Connected to: %s\n", payload);
            state_ = WebSocketState::CONNECTED;
            stats_.reconnectCount++;
            stats_.connectionUptimeMs = millis() - connectionStartMs_;
            onConnected_();
            break;
            
        case WStype_TEXT:
            handleTextMessage(String((char*)payload));
            break;
            
        case WStype_BIN:
            Serial.printf("📦 Binary data received: %u bytes\n", length);
            // معالجة البيانات الثنائية (MP3 audio مثلاً)
            break;
            
        case WStype_PING:
            Serial.println("💓 Ping from server");
            stats_.lastPingMs = millis();
            break;
            
        case WStype_PONG:
            Serial.println("💗 Pong from server");
            stats_.lastPongMs = millis();
            stats_.isHealthy = true;
            break;
            
        case WStype_ERROR:
            Serial.printf("❌ WebSocket Error: %s\n", payload);
            state_ = WebSocketState::ERROR_STATE;
            consecutiveErrors_++;
            onError_("WEBSOCKET_ERROR", String((char*)payload));
            break;
            
        default:
            Serial.printf("🔄 WebSocket Event: %d\n", type);
            break;
    }
    
    updateConnectionStats();
}

void WebSocketClient::handleTextMessage(const String& message) {
    Serial.printf("📥 Received: %s\n", message.c_str());
    
    // تحليل JSON message
    JsonDocument doc;
    DeserializationError error = deserializeJson(doc, message);
    
    if (error) {
        Serial.printf("❌ JSON parsing failed: %s\n", error.c_str());
        onError_("JSON_PARSE_ERROR", error.c_str());
        return;
    }
    
    String messageType = doc["type"].as<String>();
    stats_.messagesReceived++;
    
    // توجيه الرسالة حسب النوع
    if (messageType == "system") {
        handleSystemMessage(doc["data"]);
        
    } else if (messageType == "audio_response") {
        handleAudioResponse(doc);
        
    } else if (messageType == "text_response") {
        handleTextResponse(doc);
        
    } else if (messageType == "error") {
        handleErrorMessage(doc);
        
    } else if (messageType == "heartbeat_response") {
        handleHeartbeatResponse(doc);
        
    } else {
        Serial.printf("❓ Unknown message type: %s\n", messageType.c_str());
        // إرسال للـ callback العام
        ServerMessage serverMsg;
        serverMsg.type = messageType;
        serverMsg.data = doc;
        onMessage_(serverMsg);
    }
}

void WebSocketClient::handleSystemMessage(const JsonDocument& data) {
    String systemType = data["type"].as<String>();
    String message = data["message"].as<String>();
    
    Serial.printf("🔔 System: %s - %s\n", systemType.c_str(), message.c_str());
    
    if (systemType == "connection_established") {
        String sessionId = data["session_id"].as<String>();
        Serial.printf("🎉 Session established: %s\n", sessionId.c_str());
        state_ = WebSocketState::CONNECTED;
        
    } else if (systemType == "audio_start_ack") {
        currentAudioSessionId_ = data["audio_session_id"].as<String>();
        audioState_ = AudioSessionState::STREAMING;
        Serial.printf("🎤 Audio session ready: %s\n", currentAudioSessionId_.c_str());
    }
    
    // إرسال للـ callback
    ServerMessage serverMsg;
    serverMsg.type = "system";  
    serverMsg.data = data;
    onMessage_(serverMsg);
}

void WebSocketClient::handleAudioResponse(const JsonDocument& doc) {
    AudioResponse response;
    response.audio_data = doc["audio_data"].as<String>();
    response.text = doc["text"].as<String>();
    response.format = doc["format"] | "mp3";
    response.sample_rate = doc["sample_rate"] | 22050;
    response.timestamp = doc["timestamp"] | millis();
    
    Serial.printf("🔊 Audio response: '%s' (%s, %dHz)\n", 
                  response.text.c_str(), response.format.c_str(), response.sample_rate);
    
    stats_.audioResponsesReceived++;
    audioState_ = AudioSessionState::RECEIVING_RESPONSE;
    
    onAudioResponse_(response);
}

void WebSocketClient::handleTextResponse(const JsonDocument& doc) {
    String text = doc["text"].as<String>();
    Serial.printf("💬 Text response: %s\n", text.c_str());
    
    onTextResponse_(text);
}

void WebSocketClient::handleErrorMessage(const JsonDocument& doc) {
    String errorCode = doc["error_code"].as<String>();
    String errorMessage = doc["error_message"].as<String>();
    
    Serial.printf("❌ Server Error: %s - %s\n", errorCode.c_str(), errorMessage.c_str());
    
    consecutiveErrors_++;
    onError_(errorCode, errorMessage);
    
    // إعادة تعيين حالة الصوت في حالة خطأ
    if (audioState_ != AudioSessionState::IDLE) {
        audioState_ = AudioSessionState::IDLE;
        currentAudioSessionId_ = "";
    }
}

void WebSocketClient::handleHeartbeatResponse(const JsonDocument& doc) {
    lastHeartbeatMs_ = millis();
    stats_.isHealthy = true;
    Serial.println("💗 Heartbeat acknowledged");
}

bool WebSocketClient::startAudioSession() {
    if (!isConnected() || audioState_ != AudioSessionState::IDLE) {
        Serial.println("⚠️ Cannot start audio session");
        return false;
    }
    
    // إنشاء UUID جديد للـ audio session
    currentAudioSessionId_ = generateUUID();
    audioState_ = AudioSessionState::STARTING;
    
    // إنشاء رسالة audio_start
    JsonDocument doc;
    doc["type"] = "audio_start";
    doc["audio_session_id"] = currentAudioSessionId_;
    doc["timestamp"] = millis();
    
    bool success = sendJsonMessage(doc);
    if (success) {
        Serial.printf("🎤 Started audio session: %s\n", currentAudioSessionId_.c_str());
    }
    
    return success;
}

bool WebSocketClient::sendAudioChunk(const uint8_t* audioData, size_t length, 
                                    bool isFinal, uint32_t sequence) {
    if (!isConnected() || audioState_ == AudioSessionState::IDLE) {
        Serial.println("⚠️ Cannot send audio chunk - no active session");
        return false;
    }
    
    // تشفير البيانات الصوتية إلى base64
    String audioBase64 = encodeBase64(audioData, length);
    
    // إنشاء رسالة audio_chunk
    JsonDocument doc;
    doc["type"] = "audio_chunk";
    doc["audio_data"] = audioBase64;
    doc["chunk_id"] = generateUUID();
    doc["audio_session_id"] = currentAudioSessionId_;
    doc["is_final"] = isFinal;
    doc["sequence"] = sequence;
    doc["timestamp"] = millis();
    
    bool success = sendJsonMessage(doc);
    if (success) {
        stats_.audioChunksSent++;
        if (isFinal) {
            audioState_ = AudioSessionState::PROCESSING;
        }
    }
    
    return success;
}

bool WebSocketClient::endAudioSession() {
    if (audioState_ == AudioSessionState::IDLE) {
        return true; // Already ended
    }
    
    // إنشاء رسالة audio_end
    JsonDocument doc;
    doc["type"] = "audio_end";
    doc["audio_session_id"] = currentAudioSessionId_;
    doc["timestamp"] = millis();
    
    bool success = sendJsonMessage(doc);
    if (success) {
        Serial.printf("🎤 Ended audio session: %s\n", currentAudioSessionId_.c_str());
        audioState_ = AudioSessionState::PROCESSING;
    }
    
    return success;
}

bool WebSocketClient::sendTextMessage(const String& message) {
    if (!isConnected()) {
        return false;
    }
    
    JsonDocument doc;
    doc["type"] = "text_message";
    doc["text"] = message;
    doc["timestamp"] = millis();
    
    return sendJsonMessage(doc);
}

bool WebSocketClient::sendHeartbeat() {
    if (!isConnected()) {
        return false;
    }
    
    JsonDocument doc;
    doc["type"] = "heartbeat";
    doc["device_id"] = deviceId_;
    doc["timestamp"] = millis();
    doc["status"] = "alive";
    
    return sendJsonMessage(doc);
}

bool WebSocketClient::sendSystemStatus(const JsonDocument& status) {
    if (!isConnected()) {
        return false;
    }
    
    JsonDocument doc;
    doc["type"] = "system_status";
    doc["device_id"] = deviceId_;
    doc["timestamp"] = millis();
    doc["data"] = status;
    
    return sendJsonMessage(doc);
}

bool WebSocketClient::sendJsonMessage(const JsonDocument& doc) {
    String message;
    serializeJson(doc, message);
    
    bool success = webSocket_.sendTXT(message);
    if (success) {
        stats_.messagesSent++;
    }
    
    return success;
}

String WebSocketClient::generateUUID() {
    // UUID بسيط للـ ESP32
    String uuid = "";
    for (int i = 0; i < 32; i++) {
        if (i == 8 || i == 12 || i == 16 || i == 20) {
            uuid += "-";
        }
        int randomHex = random(16);
        uuid += String(randomHex, HEX);
    }
    return uuid;
}

String WebSocketClient::encodeBase64(const uint8_t* data, size_t length) {
    return base64::encode(data, length);
}

void WebSocketClient::loop() {
    webSocket_.loop();
    
    uint32_t now = millis();
    
    // إرسال heartbeat دوري
    if (isConnected() && now - lastHeartbeatMs_ > WS_PING_INTERVAL_MS) {
        sendHeartbeat();
        lastHeartbeatMs_ = now;
    }
    
    // محاولة إعادة الاتصال إذا كان مطلوباً
    if (state_ == WebSocketState::DISCONNECTED && shouldReconnect_ && 
        now >= nextReconnectMs_) {
        Serial.println("🔄 Attempting to reconnect...");
        webSocket_.disconnect();
        delay(1000);
        
        // إعادة إنشاء الاتصال
        String wsUrl = String(WS_ENDPOINT) + "?";
        wsUrl += "device_id=" + deviceId_;
        wsUrl += "&child_id=" + childId_;  
        wsUrl += "&child_name=" + childName_;
        wsUrl += "&child_age=" + String(childAge_);
        
        webSocket_.beginSSL(SERVER_HOST, SERVER_PORT, wsUrl);
        state_ = WebSocketState::CONNECTING;
        scheduleReconnect(); // للمحاولة التالية إذا فشلت
    }
    
    updateConnectionStats();
}

void WebSocketClient::scheduleReconnect() {
    if (reconnectAttempts_ >= WS_MAX_RECONNECT_ATTEMPTS) {
        Serial.println("❌ Max reconnect attempts reached");
        shouldReconnect_ = false;
        return;
    }
    
    // Exponential backoff
    uint32_t backoffMs = WS_RECONNECT_MIN_MS * (1 << min(reconnectAttempts_, 5u));
    backoffMs = min(backoffMs, WS_RECONNECT_MAX_MS);
    
    nextReconnectMs_ = millis() + backoffMs;
    reconnectAttempts_++;
    
    Serial.printf("⏰ Reconnect scheduled in %dms (attempt %d)\n", 
                  backoffMs, reconnectAttempts_);
}

void WebSocketClient::updateConnectionStats() {
    if (state_ == WebSocketState::CONNECTED) {
        stats_.connectionUptimeMs = millis() - connectionStartMs_;
    }
}

bool WebSocketClient::isConnected() const {
    return state_ == WebSocketState::CONNECTED && webSocket_.isConnected();
}

void WebSocketClient::disconnect() {
    shouldReconnect_ = false;
    webSocket_.disconnect();
    state_ = WebSocketState::DISCONNECTED;
    audioState_ = AudioSessionState::IDLE;
}