#include "security_manager.h"
#include "secrets_template.h" // في الإنتاج: #include "secrets.h"
#include <base64.h>
#include <ArduinoJson.h>

SecurityManager securityManager;

SecurityManager::SecurityManager() {
    // تهيئة callbacks فارغة
    onSecurityEvent_ = [](const String&, const String&, SecurityLevel) {};
    onSecurityViolation_ = [](const String&) {};
    onJWTExpired_ = []() {};
}

SecurityManager::~SecurityManager() {
    shutdown();
}

bool SecurityManager::initialize(const SecurityConfig& config) {
    if (initialized_) {
        return true;
    }
    
    Serial.println("🔐 Initializing Security Manager...");
    
    config_ = config;
    
    // تهيئة MbedTLS
    if (!initializeMbedTLS()) {
        Serial.println("❌ Failed to initialize MbedTLS");
        return false;
    }
    
    // تحميل HMAC key من secrets
    hmacSecret_ = String(HMAC_KEY_HEX);
    if (hmacSecret_.length() != 64) { // 32 bytes * 2 hex chars
        Serial.println("❌ Invalid HMAC key length");
        return false;
    }
    
    // تعيين device secret
    deviceSecret_ = String(DEVICE_SECRET);
    
    // تكوين TLS إذا كان مفعلاً
    if (config_.enableCertificatePinning) {
        trustedCertFingerprint_ = config_.trustedCertFingerprint;
        trustedPublicKeyHash_ = config_.trustedPublicKeyHash;
    }
    
    // اختبار الوظائف الأمنية
    if (!performSecuritySelfTest()) {
        Serial.println("❌ Security self-test failed");
        return false;
    }
    
    initialized_ = true;
    Serial.println("✅ Security Manager initialized");
    logSecurityEvent("SECURITY_MANAGER_INITIALIZED", "All security systems online", SecurityLevel::LOW);
    
    return true;
}

bool SecurityManager::initializeMbedTLS() {
    mbedtls_entropy_init(&entropy_);
    mbedtls_ctr_drbg_init(&ctr_drbg_);
    mbedtls_pk_init(&pk_ctx_);
    
    const char* pers = "teddy_bear_security";
    int ret = mbedtls_ctr_drbg_seed(&ctr_drbg_, mbedtls_entropy_func, &entropy_,
                                   (const unsigned char*)pers, strlen(pers));
    
    if (ret != 0) {
        Serial.printf("❌ mbedtls_ctr_drbg_seed failed: -0x%04x\n", -ret);
        cleanupMbedTLS();
        return false;
    }
    
    mbedtlsInitialized_ = true;
    return true;
}

void SecurityManager::cleanupMbedTLS() {
    if (mbedtlsInitialized_) {
        mbedtls_pk_free(&pk_ctx_);
        mbedtls_ctr_drbg_free(&ctr_drbg_);
        mbedtls_entropy_free(&entropy_);
        mbedtlsInitialized_ = false;
    }
}

bool SecurityManager::validateJWT(const String& token) {
    if (!config_.enableJWTValidation || token.isEmpty()) {
        return !config_.enableJWTValidation; // إذا كان معطل، نعتبره صحيح
    }
    
    uint32_t now = millis();
    if (now - lastJWTValidation_ < 1000) { // Rate limiting
        return true; // تجنب التحقق المتكرر
    }
    lastJWTValidation_ = now;
    
    // تحليل JWT
    JWTToken jwt = parseJWT(token);
    
    if (!jwt.isValid) {
        stats_.jwtValidationsFailed++;
        logSecurityEvent("JWT_VALIDATION_FAILED", "Invalid JWT structure or signature", SecurityLevel::HIGH);
        onJWTExpired_();
        return false;
    }
    
    if (jwt.isExpired) {
        stats_.jwtValidationsFailed++;
        logSecurityEvent("JWT_EXPIRED", "JWT token has expired", SecurityLevel::MEDIUM);
        onJWTExpired_();
        return false;
    }
    
    if (jwt.needsRefresh) {
        logSecurityEvent("JWT_NEEDS_REFRESH", "JWT token will expire soon", SecurityLevel::LOW);
    }
    
    return true;
}

JWTToken SecurityManager::parseJWT(const String& token) {
    JWTToken jwt;
    jwt.token = token;
    
    // تقسيم JWT إلى أجزاء
    int firstDot = token.indexOf('.');
    int secondDot = token.indexOf('.', firstDot + 1);
    
    if (firstDot == -1 || secondDot == -1) {
        return jwt; // Invalid structure
    }
    
    jwt.header = token.substring(0, firstDot);
    jwt.payload = token.substring(firstDot + 1, secondDot);
    jwt.signature = token.substring(secondDot + 1);
    
    // فك تشفير payload
    String decodedPayload = base64Decode(jwt.payload);
    if (decodedPayload.isEmpty()) {
        return jwt;
    }
    
    // تحليل JSON payload
    JsonDocument doc;
    DeserializationError error = deserializeJson(doc, decodedPayload);
    if (error) {
        return jwt;
    }
    
    jwt.issuedAt = doc["iat"] | 0;
    jwt.expiresAt = doc["exp"] | 0;
    jwt.issuer = doc["iss"] | "";
    jwt.subject = doc["sub"] | "";
    
    // تحقق من الصحة
    uint32_t currentTime = millis() / 1000; // Convert to seconds
    jwt.isExpired = (jwt.expiresAt > 0 && currentTime > jwt.expiresAt);
    jwt.needsRefresh = (jwt.expiresAt > 0 && (currentTime + JWT_REFRESH_BEFORE_EXPIRY_MS/1000) > jwt.expiresAt);
    
    // في التطبيق الحقيقي، يجب التحقق من التوقيع
    jwt.isValid = validateJWTStructure(token);
    
    return jwt;
}

String SecurityManager::signMessage(const String& message, const String& nonce) {
    if (!config_.enableHMACVerification) {
        return ""; // HMAC معطل
    }
    
    String fullMessage = message;
    if (!nonce.isEmpty()) {
        fullMessage += "|" + nonce;
    }
    
    String signature = calculateHMAC(fullMessage, hmacSecret_);
    
    if (!signature.isEmpty()) {
        stats_.messagesSigned++;
        lastHMACOperation_ = millis();
    }
    
    return signature;
}

String SecurityManager::signBinaryData(const uint8_t* data, size_t length, const String& nonce) {
    if (!config_.enableHMACVerification || !data || length == 0) {
        return "";
    }
    
    String signature = calculateHMACBinary(data, length, hmacSecret_);
    
    // إضافة nonce إذا وجد
    if (!nonce.isEmpty()) {
        String combined = signature + "|" + nonce;
        signature = calculateHMAC(combined, hmacSecret_);
    }
    
    if (!signature.isEmpty()) {
        stats_.messagesSigned++;
        lastHMACOperation_ = millis();
    }
    
    return signature;
}

bool SecurityManager::verifyMessageSignature(const String& message, const String& signature, const String& nonce) {
    if (!config_.enableHMACVerification) {
        return true; // HMAC معطل - قبول جميع الرسائل
    }
    
    if (signature.isEmpty()) {
        stats_.hmacVerificationsFailed++;
        incrementSecurityViolation("MISSING_HMAC_SIGNATURE");
        return false;
    }
    
    String expectedSignature = signMessage(message, nonce);
    bool isValid = constantTimeCompare(signature, expectedSignature);
    
    if (isValid) {
        stats_.messagesVerified++;
    } else {
        stats_.hmacVerificationsFailed++;
        logSecurityEvent("HMAC_VERIFICATION_FAILED", "Message signature mismatch", SecurityLevel::HIGH);
        incrementSecurityViolation("INVALID_HMAC_SIGNATURE");
    }
    
    return isValid;
}

String SecurityManager::generateSecureNonce() {
    String nonce = "";
    
    // timestamp + random data
    uint32_t timestamp = millis();
    uint32_t randomValue = generateSecureRandomNumber();
    
    char buffer[32];
    snprintf(buffer, sizeof(buffer), "%08x%08x", timestamp, randomValue);
    nonce = String(buffer);
    
    return nonce;
}

bool SecurityManager::generateSecureRandom(uint8_t* buffer, size_t length) {
    if (!mbedtlsInitialized_ || !buffer || length == 0) {
        return false;
    }
    
    int ret = mbedtls_ctr_drbg_random(&ctr_drbg_, buffer, length);
    return (ret == 0);
}

String SecurityManager::generateSecureRandomHex(size_t length) {
    uint8_t* buffer = new uint8_t[length];
    if (!buffer) {
        return "";
    }
    
    if (!generateSecureRandom(buffer, length)) {
        delete[] buffer;
        return "";
    }
    
    String hex = bytesToHex(buffer, length);
    delete[] buffer;
    
    return hex;
}

uint32_t SecurityManager::generateSecureRandomNumber() {
    uint8_t buffer[4];
    if (!generateSecureRandom(buffer, sizeof(buffer))) {
        return random(0xFFFFFFFF); // fallback to Arduino random
    }
    
    return (buffer[0] << 24) | (buffer[1] << 16) | (buffer[2] << 8) | buffer[3];
}

bool SecurityManager::setupTLSValidation(WiFiClientSecure& client) {
    if (!config_.enableTLSValidation) {
        client.setInsecure(); // تجاهل التحقق من الشهادات
        return true;
    }
    
    // تكوين التحقق من الشهادات
    if (config_.enableCertificatePinning && !trustedCertFingerprint_.isEmpty()) {
        // Certificate fingerprint pinning
        Serial.printf("🔒 Setting certificate fingerprint: %s\n", trustedCertFingerprint_.c_str());
        client.setCertificateFingerprint(trustedCertFingerprint_.c_str());
    } else {
        // استخدام CA bundle
        client.setCACert(nullptr); // سيستخدم المخزن الافتراضي
    }
    
    // تعيين SNI
    client.setServerName(TLS_SNI_NAME);
    
    return true;
}

String SecurityManager::calculateHMAC(const String& message, const String& key) {
    if (key.length() != 64) { // 32 bytes in hex
        return "";
    }
    
    // تحويل hex key إلى bytes
    uint8_t keyBytes[32];
    if (!hexToBytes(key, keyBytes, sizeof(keyBytes))) {
        return "";
    }
    
    // حساب HMAC-SHA256
    uint8_t hmac[32];
    mbedtls_md_context_t ctx;
    const mbedtls_md_info_t* md_info = mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
    
    mbedtls_md_init(&ctx);
    int ret = mbedtls_md_setup(&ctx, md_info, 1);
    if (ret != 0) {
        mbedtls_md_free(&ctx);
        return "";
    }
    
    ret = mbedtls_md_hmac_starts(&ctx, keyBytes, sizeof(keyBytes));
    if (ret != 0) {
        mbedtls_md_free(&ctx);
        return "";
    }
    
    ret = mbedtls_md_hmac_update(&ctx, (const unsigned char*)message.c_str(), message.length());
    if (ret != 0) {
        mbedtls_md_free(&ctx);
        return "";
    }
    
    ret = mbedtls_md_hmac_finish(&ctx, hmac);
    mbedtls_md_free(&ctx);
    
    if (ret != 0) {
        return "";
    }
    
    return bytesToHex(hmac, sizeof(hmac));
}

String SecurityManager::calculateHMACBinary(const uint8_t* data, size_t length, const String& key) {
    if (!data || length == 0 || key.length() != 64) {
        return "";
    }
    
    uint8_t keyBytes[32];
    if (!hexToBytes(key, keyBytes, sizeof(keyBytes))) {
        return "";
    }
    
    uint8_t hmac[32];
    mbedtls_md_context_t ctx;
    const mbedtls_md_info_t* md_info = mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
    
    mbedtls_md_init(&ctx);
    int ret = mbedtls_md_setup(&ctx, md_info, 1);
    if (ret != 0) {
        mbedtls_md_free(&ctx);
        return "";
    }
    
    ret = mbedtls_md_hmac_starts(&ctx, keyBytes, sizeof(keyBytes));
    if (ret != 0) {
        mbedtls_md_free(&ctx);
        return "";
    }
    
    ret = mbedtls_md_hmac_update(&ctx, data, length);
    if (ret != 0) {
        mbedtls_md_free(&ctx);
        return "";
    }
    
    ret = mbedtls_md_hmac_finish(&ctx, hmac);
    mbedtls_md_free(&ctx);
    
    if (ret != 0) {
        return "";
    }
    
    return bytesToHex(hmac, sizeof(hmac));
}

bool SecurityManager::constantTimeCompare(const String& a, const String& b) {
    if (a.length() != b.length()) {
        return false;
    }
    
    uint8_t result = 0;
    for (size_t i = 0; i < a.length(); i++) {
        result |= a[i] ^ b[i];
    }
    
    return result == 0;
}

String SecurityManager::bytesToHex(const uint8_t* data, size_t length) {
    String hex = "";
    hex.reserve(length * 2);
    
    for (size_t i = 0; i < length; i++) {
        char buf[3];
        snprintf(buf, sizeof(buf), "%02x", data[i]);
        hex += buf;
    }
    
    return hex;
}

bool SecurityManager::hexToBytes(const String& hex, uint8_t* output, size_t maxLength) {
    if (hex.length() % 2 != 0 || hex.length() / 2 > maxLength) {
        return false;
    }
    
    for (size_t i = 0; i < hex.length(); i += 2) {
        char highChar = hex[i];
        char lowChar = hex[i + 1];
        
        uint8_t high = (highChar >= '0' && highChar <= '9') ? (highChar - '0') :
                      (highChar >= 'a' && highChar <= 'f') ? (highChar - 'a' + 10) :
                      (highChar >= 'A' && highChar <= 'F') ? (highChar - 'A' + 10) : 16;
        
        uint8_t low = (lowChar >= '0' && lowChar <= '9') ? (lowChar - '0') :
                     (lowChar >= 'a' && lowChar <= 'f') ? (lowChar - 'a' + 10) :
                     (lowChar >= 'A' && lowChar <= 'F') ? (lowChar - 'A' + 10) : 16;
        
        if (high > 15 || low > 15) {
            return false;
        }
        
        output[i / 2] = (high << 4) | low;
    }
    
    return true;
}

String SecurityManager::base64Decode(const String& input) {
    return base64::decode(input);
}

String SecurityManager::base64Encode(const String& input) {
    return base64::encode(input);
}

bool SecurityManager::validateJWTStructure(const String& token) {
    // تحقق من وجود نقطتين
    int firstDot = token.indexOf('.');
    int secondDot = token.indexOf('.', firstDot + 1);
    
    if (firstDot == -1 || secondDot == -1) {
        return false;
    }
    
    // تحقق من طول الأجزاء
    if (firstDot < 10 || (secondDot - firstDot) < 10 || (token.length() - secondDot) < 10) {
        return false;
    }
    
    return true;
}

bool SecurityManager::validateTimestamp(uint32_t timestamp, uint32_t maxSkewMs) {
    if (maxSkewMs == 0) {
        maxSkewMs = config_.maxClockSkewMs;
    }
    
    uint32_t currentTime = millis();
    uint32_t timeDiff = (currentTime > timestamp) ? (currentTime - timestamp) : (timestamp - currentTime);
    
    return timeDiff <= maxSkewMs;
}

bool SecurityManager::validateDeviceID(const String& deviceId) {
    if (deviceId.isEmpty() || deviceId.length() < 8 || deviceId.length() > 32) {
        return false;
    }
    
    // التحقق من أن Device ID يحتوي على أحرف وأرقام فقط
    for (char c : deviceId) {
        if (!isAlphaNumeric(c) && c != '_' && c != '-') {
            return false;
        }
    }
    
    return true;
}

bool SecurityManager::validateChildData(const String& childId, const String& childName, int childAge) {
    // تحقق من UUID format للطفل
    if (childId.length() != 36) { // UUID length
        return false;
    }
    
    // تحقق من عمر الطفل (COPPA compliance)
    if (childAge < MIN_CHILD_AGE || childAge > MAX_CHILD_AGE) {
        return false;
    }
    
    // تحقق من اسم الطفل
    if (childName.isEmpty() || childName.length() > 50) {
        return false;
    }
    
    return true;
}

bool SecurityManager::performSecuritySelfTest() {
    Serial.println("🔍 Performing security self-test...");
    
    // اختبار HMAC
    String testMessage = "Hello, Security Test!";
    String signature = signMessage(testMessage);
    if (signature.isEmpty()) {
        Serial.println("❌ HMAC signing failed");
        return false;
    }
    
    bool verified = verifyMessageSignature(testMessage, signature);
    if (!verified) {
        Serial.println("❌ HMAC verification failed");
        return false;
    }
    
    // اختبار Random generation
    String randomHex = generateSecureRandomHex(16);
    if (randomHex.length() != 32) { // 16 bytes = 32 hex chars
        Serial.println("❌ Random generation failed");
        return false;
    }
    
    // اختبار JWT parsing (مع token وهمي)
    String testJWT = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";
    JWTToken jwt = parseJWT(testJWT);
    if (!jwt.isValid) {
        Serial.println("❌ JWT parsing failed");
        return false;
    }
    
    Serial.println("✅ Security self-test passed");
    return true;
}

void SecurityManager::logSecurityEvent(const String& event, const String& details, SecurityLevel severity) {
    stats_.lastSecurityEventMs = millis();
    
    String logLevel = "";
    switch (severity) {
        case SecurityLevel::LOW: logLevel = "LOW"; break;
        case SecurityLevel::MEDIUM: logLevel = "MED"; break;
        case SecurityLevel::HIGH: logLevel = "HIGH"; break;
        case SecurityLevel::CRITICAL: logLevel = "CRIT"; break;
    }
    
    Serial.printf("🔒 [%s] %s: %s\n", logLevel.c_str(), event.c_str(), details.c_str());
    
    onSecurityEvent_(event, details, severity);
    
    // في الإنتاج، يجب إرسال هذه الأحداث إلى السيرفر
}

void SecurityManager::incrementSecurityViolation(const String& violation) {
    stats_.securityViolations++;
    consecutiveSecurityFailures_++;
    
    if (consecutiveSecurityFailures_ >= MAX_CONSECUTIVE_ERRORS) {
        securityCompromised_ = true;
        stats_.isSecurityHealthy = false;
        logSecurityEvent("SECURITY_COMPROMISED", "Too many consecutive security failures", SecurityLevel::CRITICAL);
    }
    
    onSecurityViolation_(violation);
}

void SecurityManager::updateSecurityStats() {
    uint32_t now = millis();
    
    // إعادة تعيين عداد الأخطاء إذا لم تحدث أخطاء لفترة
    if (now - stats_.lastSecurityEventMs > 300000) { // 5 minutes
        consecutiveSecurityFailures_ = 0;
        securityCompromised_ = false;
        stats_.isSecurityHealthy = true;
    }
}

void SecurityManager::resetSecurityStats() {
    stats_ = SecurityStats();
    consecutiveSecurityFailures_ = 0;
    securityCompromised_ = false;
    stats_.isSecurityHealthy = true;
}

void SecurityManager::shutdown() {
    if (!initialized_) return;
    
    Serial.println("🔐 Shutting down Security Manager...");
    
    cleanupMbedTLS();
    
    // مسح المفاتيح الحساسة من الذاكرة
    hmacSecret_ = "";
    jwtSecret_ = "";
    deviceSecret_ = "";
    encryptionKey_ = "";
    
    initialized_ = false;
    Serial.println("✅ Security Manager shutdown complete");
}