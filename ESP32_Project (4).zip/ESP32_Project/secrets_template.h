#pragma once

// 🔐 AI Teddy Bear - Production Secrets Template
// ==============================================
// نسخة template - انشئ secrets.h من هذا الملف
// ⚠️ لا ترفع secrets.h للمستودع أبداً!

// 📡 WiFi Credentials
// TODO: ضع بيانات الـ WiFi الفعلية
static constexpr const char* WIFI_SSID = "YOUR_WIFI_SSID";
static constexpr const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// 🧸 Device Identity - فريد لكل teddy bear
// TODO: أنشئ معرف فريد لكل جهاز
static constexpr const char* DEVICE_ID = "teddy_bear_001"; // 8-32 chars, alphanumeric
static constexpr const char* DEVICE_SECRET = "your-device-secret-key"; // من النظام الأبوي

// 👶 Child Profile (سيأتي من التطبيق الأبوي عادة)
// TODO: هذه القيم للاختبار فقط - في الإنتاج تأتي من الـ pairing
static constexpr const char* CHILD_ID = "550e8400-e29b-41d4-a716-446655440000"; // UUID
static constexpr const char* CHILD_NAME = "Ahmed";
static constexpr int CHILD_AGE = 7; // 3-13 for COPPA compliance

// 🔑 JWT Authentication
// TODO: سيحدث عبر pairing مع التطبيق الأبوي
static constexpr const char* JWT_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."; // JWT من السيرفر

// 🔒 HMAC Security Key (32 bytes hex)
// TODO: مفتاح مشترك مع السيرفر لتوقيع الرسائل
static constexpr const char* HMAC_KEY_HEX = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";

// 🌐 TLS Certificate Validation
// Option 1: Full certificate validation (recommended for production)
#define USE_CERT_VALIDATION 1

// Option 2: Certificate fingerprint pinning (backup)
static constexpr const char* SERVER_CERT_SHA256 = 
    "AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88:99";

// Option 3: Public key pinning (most secure)
static constexpr const char* SERVER_PUBKEY_SHA256 = 
    "11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF";

// 📡 Server API Keys (if needed)
static constexpr const char* API_KEY = ""; // If server requires additional API key

// 🔄 OTA Update Configuration
static constexpr const char* OTA_SERVER_URL = "https://ai-tiddy-bear-v-xuqy.onrender.com/api/v1/ota";
static constexpr const char* OTA_UPDATE_KEY = ""; // Key for OTA authentication

// 🌍 Regional Settings
static constexpr const char* TIMEZONE = "Asia/Baghdad"; // Iraq timezone
static constexpr const char* NTP_SERVER = "pool.ntp.org";

// 🔧 Production Environment Flags
#ifdef PRODUCTION_BUILD
static constexpr bool ENABLE_DEBUG_LOGS = false;
static constexpr bool ENABLE_TEST_MODES = false;
static constexpr bool STRICT_TLS_VALIDATION = true;
#else
static constexpr bool ENABLE_DEBUG_LOGS = true;
static constexpr bool ENABLE_TEST_MODES = true;
static constexpr bool STRICT_TLS_VALIDATION = false;
#endif

// 📊 Analytics and Monitoring
static constexpr const char* DEVICE_ANALYTICS_KEY = ""; // If using analytics service
static constexpr bool ENABLE_CRASH_REPORTING = true;

// ⚡ Emergency Configurations
static constexpr const char* EMERGENCY_WIFI_SSID = ""; // Fallback WiFi
static constexpr const char* EMERGENCY_WIFI_PASSWORD = "";
static constexpr const char* EMERGENCY_SERVER_URL = ""; // Fallback server

// 📱 Development and Testing
#ifdef DEBUG_BUILD
static constexpr const char* TEST_CHILD_ID = "test-child-12345";
static constexpr const char* TEST_CHILD_NAME = "TestChild";
static constexpr int TEST_CHILD_AGE = 5;
static constexpr bool MOCK_AUDIO_INPUT = true; // للاختبار بدون مايكروفون
static constexpr bool SIMULATE_NETWORK_DELAYS = false;
#endif

// 🎯 Quality Assurance
// TODO: مفاتيح لاختبار الجودة والأمان
static constexpr const char* QA_TEST_TOKEN = "";
static constexpr bool ENABLE_QA_LOGGING = false;

// 💾 Storage Encryption
// TODO: مفاتيح لتشفير البيانات المحلية (NVS)
static constexpr const char* NVS_ENCRYPTION_KEY = "your-32-byte-nvs-encryption-key-here!"; // 32 bytes exactly

/*
🚨 SECURITY CHECKLIST:
=====================

1. ✅ تم إنشاء secrets.h من هذا الـ template
2. ✅ تم إضافة secrets.h إلى .gitignore
3. ✅ تم استخدام مفاتيح فريدة لكل جهاز
4. ✅ تم تفعيل TLS certificate validation
5. ✅ تم تشفير البيانات الحساسة في NVS
6. ✅ تم تعطيل debug logs في الإنتاج
7. ✅ تم اختبار النظام مع بيانات فعلية
8. ✅ تم توثيق عملية التحديث الآمنة

📝 PRODUCTION DEPLOYMENT NOTES:
===============================

1. Device Provisioning:
   - كل teddy bear يحتاج device_id فريد
   - يتم ربط الجهاز عبر التطبيق الأبوي أولاً
   - JWT يُحدث تلقائياً عند انتهاء الصلاحية

2. Security:
   - HMAC keys مختلفة لكل جهاز
   - TLS certificate pinning مفعل
   - NVS مشفر لحماية البيانات المحلية

3. Child Safety:
   - تطبيق صارم لقوانين COPPA
   - تسجيل محدود بـ 10 ثوان
   - فلترة محتوى آمنة للأطفال

4. Network:
   - إعادة الاتصال التلقائي
   - Fallback servers للطوارئ
   - مراقبة جودة الشبكة

5. Updates:
   - OTA updates آمنة ومشفرة
   - Rollback automatic في حالة الفشل
   - Version compatibility checks
*/