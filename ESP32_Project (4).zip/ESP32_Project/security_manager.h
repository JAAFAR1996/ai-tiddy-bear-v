#pragma once
#include <Arduino.h>
#include <mbedtls/md.h>
#include <mbedtls/entropy.h>
#include <mbedtls/ctr_drbg.h>
#include <mbedtls/pk.h>
#include <WiFiClientSecure.h>
#include "production_config.h"

// 🔐 Security Manager - Production Grade
// ======================================
// يوفر جميع الخدمات الأمنية المطلوبة للـ AI Teddy Bear:
// - JWT token management & validation  
// - HMAC message signing & verification
// - TLS certificate validation
// - Secure random number generation
// - Message encryption/decryption
// - Security event logging

enum class SecurityLevel {
    LOW,      // Basic validation
    MEDIUM,   // Standard production security
    HIGH,     // Maximum security with all checks
    CRITICAL  // Ultra-secure mode with additional measures
};

struct SecurityConfig {
    SecurityLevel level = SecurityLevel::MEDIUM;
    bool enableTLSValidation = true;
    bool enableCertificatePinning = false;
    bool enableHMACVerification = true;
    bool enableJWTValidation = true;
    bool enableMessageEncryption = false;
    uint32_t maxClockSkewMs = HMAC_MAX_CLOCK_SKEW_MS;
    String trustedCertFingerprint = "";
    String trustedPublicKeyHash = "";
};

struct JWTToken {
    String token;
    String header;
    String payload;
    String signature;
    uint32_t issuedAt = 0;
    uint32_t expiresAt = 0;
    String issuer;
    String subject;
    bool isValid = false;
    bool isExpired = false;
    bool needsRefresh = false;
};

struct SecurityStats {
    uint32_t messagesVerified = 0;
    uint32_t messagesSigned = 0;
    uint32_t hmacVerificationsFailed = 0;
    uint32_t jwtValidationsFailed = 0;
    uint32_t tlsHandshakesFailed = 0;
    uint32_t certificateValidationsFailed = 0;
    uint32_t securityViolations = 0;
    uint32_t lastSecurityEventMs = 0;
    bool isSecurityHealthy = true;
};

class SecurityManager {
public:
    SecurityManager();
    ~SecurityManager();
    
    // 🔧 Initialization
    bool initialize(const SecurityConfig& config = SecurityConfig());
    void shutdown();
    bool isInitialized() const { return initialized_; }
    
    // 🔑 JWT Token Management
    bool validateJWT(const String& token);
    JWTToken parseJWT(const String& token);
    bool isJWTExpired(const String& token);
    bool isJWTNearExpiry(const String& token, uint32_t thresholdMs = JWT_REFRESH_BEFORE_EXPIRY_MS);
    String extractJWTPayload(const String& token);
    bool setJWTSecret(const String& secret);
    
    // 🔏 HMAC Message Security
    String signMessage(const String& message, const String& nonce = "");
    String signBinaryData(const uint8_t* data, size_t length, const String& nonce = "");
    bool verifyMessageSignature(const String& message, const String& signature, const String& nonce = "");
    bool verifyBinarySignature(const uint8_t* data, size_t length, const String& signature, const String& nonce = "");
    String generateSecureNonce();
    
    // 🔒 TLS Security
    bool setupTLSValidation(WiFiClientSecure& client);
    bool validateServerCertificate(WiFiClientSecure& client);
    bool setCertificateFingerprint(const String& fingerprint);
    bool setPublicKeyHash(const String& hash);
    
    // 🎲 Secure Random Generation
    bool generateSecureRandom(uint8_t* buffer, size_t length);
    String generateSecureRandomHex(size_t length);
    uint32_t generateSecureRandomNumber();
    String generateDeviceSecret(size_t length = 32);
    
    // 🔐 Message Encryption (Optional)
    String encryptMessage(const String& plaintext, const String& key = "");
    String decryptMessage(const String& ciphertext, const String& key = "");
    bool encryptBinaryData(const uint8_t* input, size_t inputLength, uint8_t** output, size_t* outputLength);
    
    // 🛡️ Security Validation
    bool validateMessageIntegrity(const String& message, const String& expectedHash);
    bool validateTimestamp(uint32_t timestamp, uint32_t maxSkewMs = 0);
    bool validateDeviceID(const String& deviceId);
    bool validateChildData(const String& childId, const String& childName, int childAge);
    
    // 📊 Security Monitoring
    SecurityStats getSecurityStats() const { return stats_; }
    void resetSecurityStats();
    bool performSecuritySelfTest();
    void logSecurityEvent(const String& event, const String& details, SecurityLevel severity = SecurityLevel::MEDIUM);
    
    // ⚙️ Configuration
    void setSecurityLevel(SecurityLevel level);
    SecurityLevel getSecurityLevel() const { return config_.level; }
    void updateSecurityConfig(const SecurityConfig& config);
    SecurityConfig getSecurityConfig() const { return config_; }
    
    // 🚨 Security Events & Callbacks
    typedef std::function<void(const String& event, const String& details, SecurityLevel severity)> SecurityEventCallback;
    typedef std::function<void(const String& violation)> SecurityViolationCallback;
    typedef std::function<void()> JWTExpiredCallback;
    
    void onSecurityEvent(SecurityEventCallback callback) { onSecurityEvent_ = callback; }
    void onSecurityViolation(SecurityViolationCallback callback) { onSecurityViolation_ = callback; }
    void onJWTExpired(JWTExpiredCallback callback) { onJWTExpired_ = callback; }

private:
    bool initialized_ = false;
    SecurityConfig config_;
    SecurityStats stats_;
    
    // MbedTLS contexts
    mbedtls_entropy_context entropy_;
    mbedtls_ctr_drbg_context ctr_drbg_;
    mbedtls_pk_context pk_ctx_;
    bool mbedtlsInitialized_ = false;
    
    // Security keys and secrets
    String hmacSecret_;
    String jwtSecret_;
    String deviceSecret_;
    String encryptionKey_;
    
    // Certificate validation
    String trustedCertFingerprint_;
    String trustedPublicKeyHash_;
    
    // Internal functions
    bool initializeMbedTLS();
    void cleanupMbedTLS();
    
    // JWT helpers
    String base64Decode(const String& input);
    String base64Encode(const String& input);
    bool validateJWTStructure(const String& token);
    bool validateJWTSignature(const String& token);
    uint32_t extractJWTTimestamp(const String& payload, const String& claim);
    
    // HMAC helpers  
    String calculateHMAC(const String& message, const String& key);
    String calculateHMACBinary(const uint8_t* data, size_t length, const String& key);
    bool constantTimeCompare(const String& a, const String& b);
    
    // TLS helpers
    bool validateCertificateChain(WiFiClientSecure& client);
    String getCertificateFingerprint(WiFiClientSecure& client);
    String getPublicKeyHash(WiFiClientSecure& client);
    
    // Utility functions
    String bytesToHex(const uint8_t* data, size_t length);
    bool hexToBytes(const String& hex, uint8_t* output, size_t maxLength);
    void updateSecurityStats();
    void incrementSecurityViolation(const String& violation);
    
    // Security validation helpers
    bool isValidDeviceIDFormat(const String& deviceId);
    bool isValidChildAge(int age);
    bool isValidChildName(const String& name);
    bool isTimestampRecent(uint32_t timestamp);
    
    // Event callbacks
    SecurityEventCallback onSecurityEvent_;
    SecurityViolationCallback onSecurityViolation_;
    JWTExpiredCallback onJWTExpired_;
    
    // Security state
    uint32_t lastSecurityCheck_ = 0;
    uint8_t consecutiveSecurityFailures_ = 0;
    bool securityCompromised_ = false;
    
    // Rate limiting for security operations
    uint32_t lastHMACOperation_ = 0;
    uint32_t lastJWTValidation_ = 0;
    uint8_t recentSecurityOperations_ = 0;
};

// Global security instance
extern SecurityManager securityManager;